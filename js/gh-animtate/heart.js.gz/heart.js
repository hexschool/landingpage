(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.right_arm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F7EFEB").s().p("AAfBCIhagYQgKgDgFgJQgFgJADgKIAQg7QADgKAJgFQAJgFAJADIBaAYQAKADAFAJQAFAJgDAKIgQA7QgDAKgJAFQgGADgGAAIgGgBg");
	this.shape.setTransform(35.3,32.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#616161").s().p("AgUABIADgMIAnALIgEAMg");
	this.shape_1.setTransform(32,44.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#616161").s().p("AgUABIADgMIAmAKIgDANg");
	this.shape_2.setTransform(30,51.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#616161").s().p("AgUACIADgNIAnALIgEAMg");
	this.shape_3.setTransform(28,59.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#616161").s().p("AgUABIADgMIAmALIgDAMg");
	this.shape_4.setTransform(26,66.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#616161").s().p("AgUABIADgMIAnAKIgEANg");
	this.shape_5.setTransform(23.9,74.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#616161").s().p("AgUABIADgMIAmAKIgDANg");
	this.shape_6.setTransform(21.9,81.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#616161").s().p("AgUABIADgMIAnALIgEAMg");
	this.shape_7.setTransform(19.9,89.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#616161").s().p("AgUABIADgMIAnALIgEAMg");
	this.shape_8.setTransform(17.8,96.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#616161").s().p("AgUABIADgMIAnALIgEAMg");
	this.shape_9.setTransform(15.8,104.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#616161").s().p("AgVABIAEgMIAnALIgEAMg");
	this.shape_10.setTransform(13.8,111.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#616161").s().p("AgUABIADgMIAnALIgEAMg");
	this.shape_11.setTransform(11.8,119.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#616161").s().p("AgVABIAEgMIAnALIgEAMg");
	this.shape_12.setTransform(9.7,126.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#757575").s().p("Ai6JhIFNzMIAoALIlNTMg");
	this.shape_13.setTransform(18.7,93.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BDBDBD").s().p("AgGgVQAGgBAKgEIAGAvQgSAFgOABg");
	this.shape_14.setTransform(43.4,32.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#20CA9A").s().p("Ag5CpQhEgWgmhAQglg/AOhGQAJgoAXghQAXgfAhgUQALgHALAGQAMAGABANQABAPgMAHQgwAdgPA4QgQA5AfA0QAfA1A7AOQA3ANAzgfQAzgfAOg4QANg0gagxQgGgNAIgLQAHgLAOAAQANABAGALQAkBEgUBHQgVBOhHAnQgsAYgvAAQgcAAgegJg");
	this.shape_15.setTransform(39.6,17.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.right_arm, new cjs.Rectangle(0,0,58.7,155.6), null);


(lib.left_arm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F7EFEB").s().p("AgwBAQgJgFgDgKIgQg7QgDgKAFgJQAFgJAKgDIBZgYQAKgDAJAFQAJAFADAKIAQA7QADAKgFAJQgFAJgKADIhaAYIgGABQgGAAgGgDg");
	this.shape.setTransform(23.3,32.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#616161").s().p("AgUAAIAmgLIADAMIgmALg");
	this.shape_1.setTransform(26.6,44.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#616161").s().p("AgUgBIAmgKIAEAMIgnALg");
	this.shape_2.setTransform(28.7,51.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#616161").s().p("AgUAAIAmgLIADANIgmAKg");
	this.shape_3.setTransform(30.7,59.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#616161").s().p("AgUAAIAmgLIAEAMIgnALg");
	this.shape_4.setTransform(32.7,66.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#616161").s().p("AgUgBIAmgKIADAMIgmALg");
	this.shape_5.setTransform(34.8,74.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#616161").s().p("AgUgBIAmgKIAEAMIgnALg");
	this.shape_6.setTransform(36.8,81.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#616161").s().p("AgUAAIAmgLIADAMIgmALg");
	this.shape_7.setTransform(38.8,89.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#616161").s().p("AgUAAIAmgLIAEAMIgnALg");
	this.shape_8.setTransform(40.8,96.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#616161").s().p("AgUAAIAmgLIADAMIgmALg");
	this.shape_9.setTransform(42.9,104.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#616161").s().p("AgUAAIAmgLIADAMIgmALg");
	this.shape_10.setTransform(44.9,111.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#616161").s().p("AgUAAIAmgLIADAMIgmALg");
	this.shape_11.setTransform(46.9,119.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#616161").s().p("AgUAAIAmgLIADAMIgmALg");
	this.shape_12.setTransform(48.9,126.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#757575").s().p("Ai5pgIAngLIFMTMIgnALg");
	this.shape_13.setTransform(40,93.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BDBDBD").s().p("AgQAVIAHgvIAQAFIAKAwQgOgBgTgFg");
	this.shape_14.setTransform(15.3,32.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#20CA9A").s().p("AhbCaQhHgngVhOQgUhIAkhDQAGgLAOgBQANAAAHALQAIALgGANQgbAxAOA0QAOA5AzAeQAzAfA3gNQA7gOAfg1QAfg0gQg5QgPg4gwgdQgMgHABgPQABgNALgGQAMgGALAHQAhAUAXAfQAXAhAJAoQAOBGglA/QgmBAhFAWQgeAJgcAAQguAAgsgYg");
	this.shape_15.setTransform(19.1,17.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.left_arm, new cjs.Rectangle(0,0,58.7,155.6), null);


(lib.ic_mark = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F4BD3C").s().p("AgLAcIgJgHIgEgEIgDgGIgBgFIgBgGQAAgMAJgIIAEgEQADgCACgBQADgBADAAQAOgEAMAMQAJAJAAALIgBAGIgEALIgEAEIgKAHIgLACg");
	this.shape.setTransform(3,25.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F4BD3C").s().p("AgUBdQgJgJAAgMIAAiPQAAgMAJgJQAIgJAMAAQAMAAAJAJQAJAJAAAMIAACPQAAAMgJAJQgJAJgMAAQgMAAgIgJg");
	this.shape_1.setTransform(3.1,10.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ic_mark, new cjs.Rectangle(0,0,6.1,28.3), null);


(lib.eye_heart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F86183").s().p("AgNAOQgGgFAAgJQAAgHAGgGQAGgGAHAAQAIAAAGAGQAGAGAAAHQAAAJgGAFQgGAGgIAAQgHAAgGgGg");
	this.shape.setTransform(2,9.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F86183").s().p("AgNAOQgGgGAAgIQAAgHAGgGQAGgGAHAAQAIAAAGAGQAGAFAAAIQAAAIgGAGQgGAGgIAAQgIAAgFgGg");
	this.shape_1.setTransform(9.7,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F86183").s().p("AgNAOQgGgFAAgJQAAgHAGgGQAFgGAIAAQAIAAAGAGQAGAGAAAHQAAAJgGAFQgGAGgIAAQgHAAgGgGg");
	this.shape_2.setTransform(9.7,9.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F86183").s().p("AgNAOQgGgGAAgIQAAgHAGgGQAGgGAHAAQAIAAAGAGQAGAGAAAHQAAAIgGAGQgGAGgIAAQgHAAgGgGg");
	this.shape_3.setTransform(9.7,17.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F86183").s().p("AgNAOQgGgFAAgJQAAgHAGgGQAFgGAIAAQAIAAAGAGQAGAGAAAHQAAAJgGAFQgGAGgIAAQgIAAgFgGg");
	this.shape_4.setTransform(17.3,9.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F86183").s().p("AgNAOQgGgGAAgIQAAgHAGgGQAFgGAIAAQAIAAAGAGQAGAGAAAHQAAAIgGAGQgGAGgIAAQgIAAgFgGg");
	this.shape_5.setTransform(17.3,17.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F86183").s().p("AgNAOQgGgGAAgIQAAgHAGgGQAFgGAIAAQAIAAAGAGQAGAGAAAHQAAAIgGAGQgGAGgIAAQgIAAgFgGg");
	this.shape_6.setTransform(17.3,25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F86183").s().p("AgNAOQgGgGAAgIQAAgHAGgGQAGgGAHAAQAIAAAGAGQAGAGAAAHQAAAIgGAGQgGAGgIAAQgHAAgGgGg");
	this.shape_7.setTransform(25,2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F86183").s().p("AgNAOQgGgFAAgJQAAgHAGgGQAGgGAHAAQAIAAAGAGQAGAGAAAHQAAAJgGAFQgGAGgIAAQgHAAgGgGg");
	this.shape_8.setTransform(25,9.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F86183").s().p("AgNAOQgGgGAAgIQAAgHAGgGQAGgGAHAAQAIAAAGAGQAGAGAAAHQAAAIgGAGQgGAGgIAAQgHAAgGgGg");
	this.shape_9.setTransform(25,17.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F86183").s().p("AgNAOQgGgFAAgJQAAgHAGgGQAGgGAHAAQAIAAAGAGQAGAGAAAHQAAAJgGAFQgGAGgIAAQgHAAgGgGg");
	this.shape_10.setTransform(32.6,9.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.eye_heart, new cjs.Rectangle(0,0,34.6,27), null);


(lib.body = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1BB482").s().p("AAAA7QgsAAgfggQgfgfAAgsIABgLQAEApAeAaQAeAcApAAQAoABAfgcQAfgbAFgoIAAAMQAAAtggAeQgfAfgrAAIgBgBg");
	this.shape.setTransform(89.9,15.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhAAXIAAgtICBAAIAAAtg");
	this.shape_1.setTransform(83.5,206.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhUAXIAAgtICqAAIAAAtg");
	this.shape_2.setTransform(81.4,198.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhpAXIAAgsIDTAAIAAAsg");
	this.shape_3.setTransform(79.3,190.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AiOFAQgRAAgSgLQgTgKgIgPIiPj4QgJgPAAgVQAAgUAJgPICPj4QAJgOASgLQASgLARAAIEdAAQARAAASALQASAKAJAPICPD4QAJAPAAAUQAAAVgJAPIiPD4QgJAPgSAKQgSALgRAAgAiRj9QgHAEgDAEIiHDqQgCAEAAAHQAAAJACADICHDqQACAEAIAEQAHAEAEAAIEMAAQAFAAAHgEQAIgEACgEICGjqQADgDAAgJQAAgHgDgEIiGjqQgDgEgHgEQgHgEgFAAIkMAAQgEAAgHAEg");
	this.shape_4.setTransform(89.9,187.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E0E0E0").s().p("AhAAWIAAgsICBAAIAAAsg");
	this.shape_5.setTransform(83.5,207.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E0E0E0").s().p("AhUAXIAAgtICqAAIAAAtg");
	this.shape_6.setTransform(81.4,199.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E0E0E0").s().p("AhpAXIAAgtIDTAAIAAAtg");
	this.shape_7.setTransform(79.3,191.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E0E0E0").s().p("AiOE/QgRAAgSgKQgTgKgIgPIiPj4QgJgPAAgVQAAgUAJgOICPj5QAIgPATgKQASgLARAAIEdAAQARAAASALQASAKAJAPICPD5QAJAOAAAUQAAAVgJAPIiPD4QgJAPgSAKQgSAKgRAAgAiRj9QgHAEgDAEIiHDpQgCAFAAAHQAAAJACADICHDqQACADAIAFQAHAEAEAAIEMAAQAFAAAHgEQAIgFACgDICGjqQADgDAAgJQAAgHgDgFIiGjpQgDgEgHgEQgHgEgFAAIkMAAQgEAAgHAEg");
	this.shape_8.setTransform(89.9,188.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#20CA9A").s().p("AgBBrQgrgBgfgfQggggABgrQABgtAggfQAfgfArABQAsAAAgAgQAfAfgBAsQAAAsggAfQgfAfgrAAIgCAAg");
	this.shape_9.setTransform(89.9,10.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#757575").s().p("AgQB4IADjwIAeABIgDDwg");
	this.shape_10.setTransform(89.9,26.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#BDBDBD").s().p("AgnioQASAAAOAEIAvE5QgnAUgoAAg");
	this.shape_11.setTransform(165.4,122.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E0E0E0").s().p("Ah4AUQgKAAgLgEQgHgJgGgNIgFgNQAFALALAHQALAGAMAAIDxAAQAMAAALgGQAKgHAFgLIABAAQgGAVgMAOQgLAEgKAAg");
	this.shape_12.setTransform(89.1,49);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ah4BgQgRgBgOgIQgPgKgGgPIhHiYIAPgEIBGCWQAFALAKAHQALAGAMAAIDxAAQAMAAALgGQALgHAEgLIBHiWIAOAEIhGCYQgIAPgOAKQgOAIgRABg");
	this.shape_13.setTransform(89.1,41.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#424242").s().p("Al1DQQibhWAAh6QAAh5CbhWQCbhWDaAAQDbAACbBWQCbBWAAB5QAAB6ibBWQibBWjbAAQjaAAibhWg");
	this.shape_14.setTransform(89,93.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#E0E0E0").s().p("Al1DQQibhWAAh6QAAh5CbhWQCbhWDaAAQDbAACbBWQCbBWAAB5QAAB6ibBWQibBWjbAAQjaAAibhWg");
	this.shape_15.setTransform(89,89.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E0E0E0").s().p("Al1DQQibhWAAh6QAAh5CbhWQCbhWDaAAQDbAACbBWQCbBWAAB5QAAB6ibBWQibBWjbAAQjaAAibhWg");
	this.shape_16.setTransform(89,96.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#E0E0E0").s().p("AhTioQBGAAAwAyQAxAxAABFQAABGgxAxQgwAyhGAAg");
	this.shape_17.setTransform(169.8,122.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E0E0E0").s().p("AgiB3QgxgxAAhGQAAhFAxgxQAxgyBFAAIAAFRQhGAAgwgyg");
	this.shape_18.setTransform(8.4,122.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F2F2F2").s().p("AkYTfQiCg2hkhkQhkhkg3iCQg5iHAAiTIAAyKQAAiTA5iGQA3iCBkhkQBkhkCCg2QCGg5CSAAQCTAACGA5QCCA2BkBkQBkBkA3CCQA5CGAACTIAASKQAACTg5CHQg3CChkBkQhkBkiCA2QiGA5iTAAQiSAAiGg5g");
	this.shape_19.setTransform(89.1,158.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.body, new cjs.Rectangle(0,0,178.3,289.1), null);


// stage content:
(lib.animate = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// eye_heart
	this.instance = new lib.eye_heart();
	this.instance.parent = this;
	this.instance.setTransform(177,147.1,1,1,0,0,0,17.3,13.5);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:144.5,alpha:0.667},0).wait(1).to({y:141.8,alpha:0.833},0).wait(1).to({y:139.2,alpha:1},0).wait(1).to({y:142.4,alpha:0.938},0).wait(1).to({y:145.6,alpha:0.875},0).wait(1).to({y:148.8,alpha:0.813},0).wait(1).to({y:152,alpha:0.75},0).wait(1).to({y:150.8,alpha:0.688},0).wait(1).to({y:149.6,alpha:0.625},0).wait(1).to({y:148.3,alpha:0.563},0).wait(1).to({y:147.1,alpha:0.5},0).wait(1));

	// body
	this.instance_1 = new lib.body();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176.2,196.8,1,1,0,0,0,89.1,144.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(12));

	// left_arm
	this.instance_2 = new lib.left_arm();
	this.instance_2.parent = this;
	this.instance_2.setTransform(104.4,189.4,1,1,0,0,0,58.1,155.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({regX:29.3,regY:77.8,rotation:-2.6,x:72.1,y:113.3},0).wait(1).to({rotation:-5.1,x:68.8,y:114.8},0).wait(1).to({rotation:-7.7,x:65.5,y:116.5},0).wait(1).to({rotation:-6.8,x:66.7,y:115.8},0).wait(1).to({rotation:-5.8,x:67.9,y:115.2},0).wait(1).to({rotation:-4.8,x:69.2,y:114.6},0).wait(1).to({rotation:-3.9,x:70.5,y:114},0).wait(1).to({rotation:-2.9,x:71.7,y:113.4},0).wait(1).to({rotation:-1.9,x:73,y:112.9},0).wait(1).to({rotation:-1,x:74.3,y:112.4},0).wait(1).to({rotation:0,x:75.6,y:111.9},0).wait(1));

	// right_arm
	this.instance_3 = new lib.right_arm();
	this.instance_3.parent = this;
	this.instance_3.setTransform(247.7,188.6,1,1,0,0,0,0.1,155.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({regX:29.3,regY:77.8,rotation:2.5,x:280.2,y:111.9},0).wait(1).to({rotation:4.9,x:283.5,y:113.4},0).wait(1).to({rotation:7.4,x:286.6,y:115},0).wait(1).to({rotation:6.4,x:285.5,y:114.4},0).wait(1).to({rotation:5.5,x:284.3,y:113.8},0).wait(1).to({rotation:4.6,x:283.1,y:113.2},0).wait(1).to({rotation:3.7,x:281.9,y:112.7},0).wait(1).to({rotation:2.8,x:280.6,y:112.1},0).wait(1).to({rotation:1.8,x:279.4,y:111.6},0).wait(1).to({rotation:0.9,x:278.2,y:111.1},0).wait(1).to({rotation:0,x:276.9,y:110.6},0).wait(1));

	// ic_mark
	this.instance_4 = new lib.ic_mark();
	this.instance_4.parent = this;
	this.instance_4.setTransform(177,31.4,1,1,0,0,0,3,14.2);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(3).to({_off:false},0).wait(1).to({y:32.2},0).wait(1).to({y:33},0).wait(1).to({y:33.8},0).wait(1).to({y:34.7},0).wait(1).to({y:33.8},0).wait(1).to({y:33},0).wait(1).to({y:32.2},0).wait(1).to({y:31.4},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(221.3,132.8,260,308.6);
// library properties:
lib.properties = {
	id: 'D56318B5E08A487494544939185D9236',
	width: 350,
	height: 200,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['D56318B5E08A487494544939185D9236'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createHeartjs = createjs||{}, AdobeAn = AdobeAn||{});
var createHeartjs, AdobeAn;