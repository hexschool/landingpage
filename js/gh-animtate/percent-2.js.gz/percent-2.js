(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.wave = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#20CA9A").s().p("AAwAdQgGgCgCgFQgNgWgZAAQgMgBgLAFQgLAGgGALQgDAFgGACQgGABgFgDQgHgEABgIQAAgEACgDQAKgQASgKQASgKATABQATABAQAJQAQAKAKAQIACAIQAAAHgHAEQgEACgEAAIgDAAg");
	this.shape.setTransform(-0.2,5.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#20CA9A").s().p("AB9AuQgGgBgDgFQgUgagegOQgdgPghgCQgigBgfANQgfANgXAaQgEAFgGAAQgFABgFgEQgFgFAAgGQABgGADgDQAbgeAlgQQAlgQAoABQAnACAjASQAjASAYAeQADAEAAAFQAAAHgFAEQgFADgEAAIgCAAg");
	this.shape_1.setTransform(0,-3.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#424242").s().p("ABYAlQgGAAgDgFQgcgmgwgDQgXAAgWAJQgWAKgOASQgEAFgFABQgGAAgEgDQgGgEAAgIQABgEACgEQATgXAcgNQAbgNAeACQAdABAaAOQAZAOARAXQADAEAAAEQgBAIgFADQgDADgEAAIgDgBg");
	this.shape_2.setTransform(-0.1,0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.wave, new cjs.Rectangle(-14,-8.1,28.2,16.3), null);


(lib.text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AlvAFIAAgJILfAAIAAAJg");
	this.shape.setTransform(62,-0.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#424242").s().p("AguBHIBMiNIARAAIhMCNgAAaBCQgEgCgFgEQgDgFAAgHQgCgGAAgKQAAgIACgIQAAgGADgFQAEgFAFgBQAFgCAKAAQAKAAAEACQAGACADAEQACAFACAGIAAAgQgCAHgCAFQgEAEgFACQgEACgKAAQgKAAgFgCgAAhAQIgBAQQAAANABAEQACAFAGAAQAFAAACgFQABgGAAgLQAAgKgBgGQgCgFgFAAQgGAAgCAFgAg1ACQgFgCgDgEQgEgEgBgHIgBgQIABgQQABgHAEgEQADgFAFgCQAHgCAHAAQAJAAAGACQAFACAEAFQADAFAAAGIABAQIgBAQQAAAGgDAFQgEAEgFACQgGACgJAAQgHAAgHgCgAgugvQgBAFAAAKQAAALABAGQACAGAFAAQAGAAACgGIABgRIgBgPQgCgGgGAAQgFAAgCAGg");
	this.shape_1.setTransform(11.2,-0.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#424242").s().p("AgVBAQgIgEgEgFQgFgHgBgGIgBgMIAAgDIAaAAIAAAHQAAAEACADIAEAFQADADAEAAQAHAAAEgHQAEgGAAgOIgBgNIgCgJIgFgEIgHgBQgGAAgDADQgDADgBAFIgYAAIAFhIIBFAAIAAAWIgxAAIgDAeIABAAQADgFAHgCQAFgDAIAAQALAAAFAEQAGADAEAHQAEAGACAGQABAIAAAIQAAAMgCAIQgBAIgFAIQgFAGgJAEQgIADgMAAQgNAAgHgDg");
	this.shape_2.setTransform(-0.8,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#424242").s().p("AAABDIAAheIgaAAIAAgSIACAAQAOAAAIgEQAHgGACgLIAUAAIAACFg");
	this.shape_3.setTransform(-10.8,-0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#424242").s().p("AgKBMIAAgWIg/AAIAAgSIA/AAIAAgIIgvAAIAAhAIAvAAIAAgIIg7AAIAAgSIA7AAIAAgNIATAAIAAANIA8AAIAAASIg8AAIAAAIIAwAAIAABAIgwAAIAAAIIBBAAIAAASIhBAAIAAAWgAAJAMIAcAAIAAgKIgcAAgAgmAMIAcAAIAAgKIgcAAgAAJgLIAcAAIAAgKIgcAAgAgmgLIAcAAIAAgKIgcAAg");
	this.shape_4.setTransform(-26.1,0);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#424242").s().p("AgtBMIAAg1IgYAIIgFgSIAdgIIAAgeIgLAAQgDAMgDAIIgNgIQAGgSADgjIAQADIgDAUIAIAAIAAggIARAAIAAAgIAOAAIAAASIgOAAIAAAZIAQgDIACAQIgSAFIAAA6gAAhBKQgBgKgFgJIAPABQADAAADgEQAGgHAEhNIgBAAQgPBKgkAeQgEgEgLgIQAjgZAPhDIgIAAQgMAugYAZQgGgHgJgEQAXgUAMgoIgJAAQgGASgJALIgOgKQASgUAHgqIASAEIgHAVIA+AAIgBAJQgEBggIAKQgFAHgIACIgJAAIgJAAg");
	this.shape_5.setTransform(-42.5,0);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#424242").s().p("AgGBMIAAgbIgJAAIAAgNIAJAAIAAgoIAcAAIAAgGIgkAAIAAgOIATAAIAAgGIgNAAIAAgNIANAAIAAgGIgRAAIAAgOIARAAIAAgMIARAAIAAAMIARAAIAAgMIARAAIAAAMIASAAIAAAOIgSAAIAAAGIAPAAIAAANIgPAAIAAAGIAUAAIAAAOIglAAIAAAGIAeAAIAAAoIAIAAIAAANIgIAAIAAAJQAAALgHAEQgGACgRAAQgCgJgEgGIAQAAQAAAAABAAQAAAAABAAQAAgBAAAAQAAgBAAAAIAAgJIgqAAIAAAbgAAnAkIAMAAIAAgIIgMAAgAAJAkIANAAIAAgIIgNAAgAAnAQIAMAAIAAgIIgMAAgAAJAQIANAAIAAgIIgNAAgAAWgYIARAAIAAgGIgRAAgAAWgrIARAAIAAgGIgRAAgAhLBCQAKgLAHgTIARADQgIAXgMAOgAgnApIANgGQALARADAKIgPAHQgCgKgKgSgAhCAjIAAhoIAxAAIAABogAgyATIAQAAIAAgPIgQAAgAgygJIAQAAIAAgPIgQAAgAgygnIAQAAIAAgPIgQAAg");
	this.shape_6.setTransform(-58.7,0);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#424242").s().p("AhMA3QAxgYAOhCIAJACIgCgRIglAAIAAgUIA4AAQgBBWBBAmQgLAIgFAIQgrgZgRg1QgRA2gpAZg");
	this.shape_7.setTransform(-74.8,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#424242").s().p("AhIA+QAVgbACg+IgTAAIAAgTIATAAIABgdIATAAIAAAdIAiAAIAAAIQgEBbgGAKQgFAIgHABQgGABgNAAQgBgMgEgJIANACQADgBADgDQAGgHAChGIgQAAQgDBHgYAgQgIgLgHgDgAAMBJIAAiCIA9AAIAACAIgUAAIAAgKIgVAAIAAAMgAAgAqIAVAAIAAhQIgVAAg");
	this.shape_8.setTransform(-91.4,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text, new cjs.Rectangle(-98.7,-7.6,197.6,15.2), null);


(lib.shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0E0E0").s().p("AjsAnQhigQAAgXQAAgWBigRQBigQCKAAQCLAABiAQQBiARAAAWQAAAXhiAQQhiARiLAAQiKAAhigRg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(-33.5,-5.6,67.1,11.2), null);


(lib.eye = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#20CA9A").s().p("AgKALQgFgEAAgHQAAgGAFgFQAEgEAGAAQAHAAAFAEQAEAFAAAGQAAAHgEAEQgGAFgGAAQgGAAgEgFg");
	this.shape.setTransform(-12.3,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#20CA9A").s().p("AgKAMQgFgGAAgGQAAgGAFgEQAEgFAGAAQAHAAAEAFQAFAEAAAGQAAAGgFAGQgEAEgHAAQgGAAgEgEg");
	this.shape_1.setTransform(-6.2,-6.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#20CA9A").s().p("AgKALQgFgFAAgGQAAgGAFgFQAEgEAGAAQAHAAAEAEQAFAFAAAGQAAAHgFAEQgEAFgHAAQgGAAgEgFg");
	this.shape_2.setTransform(-6.2,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#20CA9A").s().p("AgKAMQgFgFAAgHQAAgFAFgFQAEgFAGAAQAHAAAEAFQAFAFAAAFQAAAHgFAFQgEAEgHAAQgGAAgEgEg");
	this.shape_3.setTransform(-6.2,6.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#20CA9A").s().p("AgKAMQgFgFAAgHQAAgFAFgFQAFgFAFAAQAHAAAFAFQAEAEAAAGQAAAHgEAFQgFAEgHAAQgGAAgEgEg");
	this.shape_4.setTransform(0,-12.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#20CA9A").s().p("AgKAMQgFgGAAgGQAAgGAFgEQAEgFAGAAQAHAAAFAFQAEAEAAAGQAAAHgEAFQgFAEgHAAQgGAAgEgEg");
	this.shape_5.setTransform(0,-6.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#20CA9A").s().p("AgKALQgFgEAAgHQAAgGAFgFQAEgEAGAAQAHAAAFAEQAEAFAAAGQAAAHgEAEQgFAFgHAAQgFAAgFgFg");

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#20CA9A").s().p("AgKAMQgFgFAAgHQAAgFAFgFQAFgFAFAAQAHAAAFAFQAEAEAAAGQAAAHgEAFQgFAEgHAAQgGAAgEgEg");
	this.shape_7.setTransform(0,6.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#20CA9A").s().p("AgKALQgFgEAAgHQAAgFAFgFQAEgFAGAAQAHAAAFAFQAEAFAAAFQAAAHgEAEQgFAFgHAAQgGAAgEgFg");
	this.shape_8.setTransform(0,12.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#20CA9A").s().p("AgKAMQgFgFAAgHQAAgGAFgEQAFgFAFAAQAHAAAEAFQAFAEAAAGQAAAHgFAFQgEAEgHAAQgFAAgFgEg");
	this.shape_9.setTransform(6.2,-6.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#20CA9A").s().p("AgKALQgFgEAAgHQAAgGAFgFQAFgEAFAAQAHAAAEAEQAFAFAAAGQAAAHgFAEQgEAFgHAAQgFAAgFgFg");
	this.shape_10.setTransform(6.2,0);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#20CA9A").s().p("AgKAMQgFgFAAgHQAAgGAFgEQAFgFAFAAQAHAAAEAFQAFAEAAAGQAAAHgFAFQgEAEgHAAQgFAAgFgEg");
	this.shape_11.setTransform(6.2,6.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#20CA9A").s().p("AgKALQgFgFAAgGQAAgGAFgFQAEgEAGAAQAHAAAEAEQAFAFAAAGQAAAHgFAEQgEAFgHAAQgGAAgEgFg");
	this.shape_12.setTransform(12.3,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.eye, new cjs.Rectangle(-13.9,-13.9,27.9,27.9), null);


(lib.boxyellow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AlYAFIAAgJIKxAAIAAAJg");
	this.shape.setTransform(-4.7,-8.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#424242").s().p("AguBHIBLiNIASAAIhNCNgAAaBCQgGgCgDgEQgDgFgBgHQgBgGgBgKQABgIABgHQABgHADgFQADgFAGgBQAHgCAHAAQAHAAAIACQAFACADAEQADAFABAHIABAPIgBAQQgBAHgDAFQgDAEgFACQgIACgHAAQgHAAgHgCgAAhAQQgBAEAAAMQAAANABAEQABAFAGAAQAFAAACgFQACgGgBgLQABgKgCgGQgCgFgFAAQgGAAgBAFgAg1ACQgGgCgDgEQgDgEgCgHIgBgQIABgQQACgHADgEQACgEAHgDQAGgCAIAAQAIAAAGACQAGADADAEQAEAFAAAGIABAQIgBAQQAAAGgEAFQgDAEgGACQgFACgJAAQgJAAgFgCgAgugvQgCAFAAAKQAAAMACAFQABAGAGAAQAFAAACgGIABgRIgBgPQgCgGgFAAQgGAAgBAGg");
	this.shape_1.setTransform(-52.6,-7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#424242").s().p("AgUBBQgHgDgFgIQgGgJgBgLQgCgMAAgTIABgZQABgOAEgJQADgKAKgGQAIgGAOAAQAMAAAIADQAIAEAFAIQAEAGADAOQACALAAATIgBAaQgBAMgEALQgFAKgIAFQgJAGgOAAQgKAAgKgDgAgGgvQgEACgBAFQgCAHAAAHIAAA4QAAAHACAGIAFAGQADACADAAQAFAAACgCQADgDACgFQABgEABgKIAAg4QgBgJgBgDQgCgEgDgDQgDgBgEAAQgEAAgCACg");
	this.shape_2.setTransform(-64.5,-7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#424242").s().p("AgfA5QgJgKAAgUIAAAAIAaAAQAAAMACAGQAEAGAIAAQAFAAACgCIAFgFIACgGIAAgRQgBgFgCgDQgBgDgEgCQgEgCgEAAIgKAAIAAgQIAJAAQADAAAEgCQADgCABgDIAEgHIAAgIQAAgJgDgEQgDgEgGAAQgEAAgDABQgDACgCADIgBAHIAAAIIgZAAQgBgUAKgJQALgKASAAQASAAAKAIQALAJAAARQAAAMgGAIQgFAIgKACIAAAAQANACAFAIQAGAIgBANQAAAHgBAHQgCAHgFAGQgFAGgIADQgKAEgMAAQgTAAgKgLg");
	this.shape_3.setTransform(-73.6,-7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#424242").s().p("AgKBMIAAgWIg/AAIAAgSIA/AAIAAgIIguAAIAAhAIAuAAIAAgIIg7AAIAAgSIA7AAIAAgNIATAAIAAANIA8AAIAAASIg8AAIAAAIIAwAAIAABAIgwAAIAAAIIBAAAIAAASIhAAAIAAAWgAAJAMIAcAAIAAgKIgcAAgAgmAMIAcAAIAAgKIgcAAgAAJgLIAcAAIAAgKIgcAAgAgmgLIAcAAIAAgKIgcAAg");
	this.shape_4.setTransform(-89.9,-6.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#424242").s().p("AgtBMIAAg1IgZAHIgEgSIAdgHIAAgeIgLAAQgCAMgEAIIgNgIQAGgTADgiIAQADIgDATIAIAAIAAgfIASAAIAAAfIANAAIAAATIgNAAIAAAZIAPgDIACAQIgRAFIAAA6gAAhBKQgBgLgFgIIAPABQADAAADgDQAGgJADhMIAAAAQgOBKglAeQgEgFgLgHQAjgZAPhDIgIAAQgNAvgXAXQgFgGgKgFQAXgSAMgpIgIAAQgIASgIALIgOgLQARgUAIgpIARADIgFAWIA9AAIgBAJQgEBfgIALQgFAHgHABIgKABIgJAAg");
	this.shape_5.setTransform(-106.3,-6.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#424242").s().p("AAiA8IAOAAQABAAABAAQAAAAABAAQAAgBAAAAQABgBAAAAIAAgJIgrAAIAAAbIgPAAIAAgbIgJAAIAAgNIAJAAIAAgoIAcAAIAAgGIgkAAIAAgOIATAAIAAgGIgNAAIAAgNIANAAIAAgGIgQAAIAAgNIAQAAIAAgNIARAAIAAANIAQAAIAAgNIARAAIAAANIASAAIAAANIgSAAIAAAGIAQAAIAAANIgQAAIAAAGIAVAAIAAAOIgmAAIAAAGIAfAAIAAAoIAIAAIAAANIgIAAIAAAJQAAALgHAEQgGADgSAAQgCgKgCgGgAAmAkIAOAAIAAgIIgOAAgAAJAkIANAAIAAgIIgNAAgAAmAQIAOAAIAAgHIgOAAgAAJAQIANAAIAAgHIgNAAgAAWgYIAQAAIAAgGIgQAAgAAWgrIAQAAIAAgGIgQAAgAhLBCQAKgLAGgTIARAEQgHAWgMAOgAgnApIANgGQALARAEAKIgQAHQgCgKgKgSgAhCAjIAAhoIAxAAIAABogAgyATIAQAAIAAgPIgQAAgAgygJIAQAAIAAgPIgQAAgAgygnIAQAAIAAgPIgQAAg");
	this.shape_6.setTransform(-122.5,-6.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#424242").s().p("AABgIQgSA2goAZQgKgKgIgFQAvgZAPhBIAKABIgDgRIglAAIAAgUIA4AAQAABXBAAlQgKAIgGAJQgsgagQg1g");
	this.shape_7.setTransform(-138.6,-6.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#424242").s().p("AhNA6QAJgKAIgGQAGgOAEgOIgVAAIAMgiIgPAAIAAgRIAmAAIgLAkIAHAAIADgBIAIACQgFAXgIATIAKAGQANAIAfAAQAhAAAhgEQgGAPAAAEIg9ACQgeABgQgJIgJgGQgEgEgCAAQgFABgJAUgAgTAyIAAhDIgJAJQgGgNgEgFQAVgTAKgeIARAFQgEAMgFAJIAYAAIgIgSIASgFQAHAKAEANIAZAAIAAAQIggAAIAAAJIAaAAIAAAPIgaAAIAAAJIAZAAIAAARIgZAAIAAAJIAiAAIAAARIhKAAIAAAHgAgBAaIAVAAIAAgJIgVAAgAgBAAIAVAAIAAgJIgVAAgAgBgYIAVAAIAAgJIgVAAgAhBhGIARgFIAJAbIgSAGIgIgcg");
	this.shape_8.setTransform(-154.8,-6.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F0B32A").s().p("ApOABIJOlGIJPFFIpPFGg");
	this.shape_9.setTransform(89.1,-18);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DA9E24").s().p("AlvgPIJPlHICQEaIrfGTg");
	this.shape_10.setTransform(125.9,16.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FDC12D").s().p("Alug9ICPkZIJOFGIAAFmg");
	this.shape_11.setTransform(52.4,16.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FDC12D").s().p("AreBmICPkYIJPlHIJPFGICQEZIrfGUg");
	this.shape_12.setTransform(89.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.boxyellow, new cjs.Rectangle(-162.6,-50.6,325.3,101.2), null);


(lib.boxtop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AmLAFIAAgJIMXAAIAAAJg");
	this.shape.setTransform(11.9,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#424242").s().p("AguBHIBMiNIARAAIhMCNgAAaBCQgGgCgDgEQgDgFgBgHIgBgQIABgPQABgHADgFQADgEAGgCQAIgCAGAAQAHAAAIACQAFACADAEQAEAFAAAHQACAHAAAIQAAAKgCAGQAAAHgEAFQgCAEgGACQgIACgHAAQgGAAgIgCgAAhAQQgBAGAAAKQAAALABAGQACAFAFAAQAGAAABgFQABgEAAgNQAAgMgBgEQgBgFgGAAQgFAAgCAFgAg1ACQgGgCgDgEQgEgFAAgGQgCgHAAgJQAAgJACgHQAAgGAEgFQADgEAGgDQAGgCAIAAQAIAAAGACQAGADADAEQADAEABAHIABAQIgBAQQgBAHgDAEQgDAEgGACQgEACgKAAQgKAAgEgCgAgugvIgBAPIABARQABAGAGAAQAGAAABgGQABgFAAgMQAAgKgBgFQgBgGgGAAQgGAAgBAGg");
	this.shape_1.setTransform(-43.4,-1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#424242").s().p("AAABDIAAhdIgaAAIAAgSIADAAQANAAAIgGQAHgFACgLIAUAAIAACFg");
	this.shape_2.setTransform(-56.3,-1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#424242").s().p("AhKA7QAagFATgJIgZAAIAAhGIBtAAIAABGIgbAAQAWAHAZALIgVAJQgQgJgdgKIANgIIgtAAIAPAGQgVANgfAJQgGgIgIgGgAgjAhIBGAAIAAgIIhGAAgAgjANIBGAAIAAgIIhGAAgAgjgFIBGAAIAAgIIhGAAgAg/ggIAAgoIB/AAIAAAogAAZguIAUAAIAAgLIgUAAgAgKguIATAAIAAgLIgTAAgAgtguIATAAIAAgLIgTAAg");
	this.shape_3.setTransform(-71.6,-0.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#424242").s().p("AAhA8IAQAAQAAAAABAAQAAAAABAAQAAgBAAAAQAAgBAAAAIAAgJIgpAAIAAAbIgQAAIAAgbIgJAAIAAgNIAJAAIAAgoIAcAAIAAgGIgkAAIAAgOIATAAIAAgGIgMAAIAAgNIAMAAIAAgGIgRAAIAAgNIARAAIAAgNIARAAIAAANIARAAIAAgNIARAAIAAANIARAAIAAANIgRAAIAAAGIAPAAIAAANIgPAAIAAAGIAUAAIAAAOIglAAIAAAGIAeAAIAAAoIAIAAIAAANIgIAAIAAAJQAAALgHAEQgHADgQAAQgDgKgDgGgAAnAkIAMAAIAAgIIgMAAgAAKAkIAMAAIAAgIIgMAAgAAnAQIAMAAIAAgHIgMAAgAAKAQIAMAAIAAgHIgMAAgAAWgYIARAAIAAgGIgRAAgAAWgrIARAAIAAgGIgRAAgAhMBCQALgLAHgTIAQAEQgGAWgNAOgAgoAqIAPgHQAKARADAKIgPAHQgCgLgLgQgAhDAjIAAhoIAyAAIAABogAgyATIAQAAIAAgPIgQAAgAgygJIAQAAIAAgPIgQAAgAgygnIAQAAIAAgPIgQAAg");
	this.shape_4.setTransform(-87.9,-0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4CC3AD").s().p("AiSlwIElI/IklCig");
	this.shape_5.setTransform(80.9,0);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#5CECD2").s().p("AiSDPIElo/IAALhg");
	this.shape_6.setTransform(51.5,0);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#5CECD2").s().p("AklDPIElo/IEmI/IkmCig");
	this.shape_7.setTransform(66.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.boxtop, new cjs.Rectangle(-95.6,-36.8,191.2,73.7), null);


(lib.boxred = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AnWAFIAAgJIOuAAIAAAJg");
	this.shape.setTransform(-37.7,-8.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#424242").s().p("AgtBHIBLiNIARAAIhMCNgAAbBCQgGgBgDgFQgEgFgBgHIgBgQIABgQQABgGAEgFQAEgFAFgBQAEgCAJAAQALAAAEACQAFABAEAFQADAEABAHIAAAgQgCAJgCADQgDAEgGACQgEACgLAAQgJAAgEgCgAAhAQIgBAQIABARQACAFAFAAQAHAAAAgFQACgGAAgLQAAgKgCgGQAAgFgHAAQgFAAgCAFgAg1ACQgFgCgDgEQgDgEgCgHIgBgQIABgQQACgHADgEQADgFAFgCQAHgCAHAAQAJAAAGACQAFACAEAFQADAFAAAGQACAHAAAJQAAAJgCAHQAAAGgDAFQgEAEgFACQgGACgJAAQgHAAgHgCgAgtgvQgCAFAAAKQAAALACAGQABAGAFAAQAGAAABgGQACgGAAgLQAAgKgCgFQgBgGgGAAQgFAAgBAGg");
	this.shape_1.setTransform(-99.4,-6.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#424242").s().p("AgTBBQgIgDgFgIQgEgGgDgOQgCgLAAgUIABgZQABgOAEgJQAFgKAHgGQAJgGAOAAQALAAAJAEQAJAEAEAHQAFAGACAOQACAMAAASIgBAaQgBAMgEALQgFAKgHAGQgIAFgQAAQgLAAgIgDgAgHgvQgDACgBAFIgCAPIAAA3QABAKACADQABAEADACQACACAEAAQAFAAADgCQADgCABgFIACgPIAAg3QgBgKgCgDQgBgFgDgBQgCgCgFAAQgEAAgDACg");
	this.shape_2.setTransform(-111.2,-6.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#424242").s().p("AgTBBQgIgDgFgIQgFgGgCgOQgCgRAAgOIABgZQABgMAEgLQAFgKAHgGQAJgGAOAAQALAAAJAEQAIADAGAIQAFAIABAMQACAMAAASIgBAaQgBAOgEAJQgEAKgIAGQgIAFgQAAQgKAAgJgDgAgHgvQgCACgBAFQgCAFgBAKIAAA3QABAKACADQABAEADACQADACADAAQAFAAADgCQADgCABgFQACgHAAgIIAAg3QAAgHgCgGQgCgFgCgBQgDgCgFAAQgEAAgDACg");
	this.shape_3.setTransform(-120.3,-6.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#424242").s().p("AAABDIAAhdIgaAAIAAgSIACAAQAPAAAHgGQAHgEACgMIAUAAIAACFg");
	this.shape_4.setTransform(-130.5,-7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#424242").s().p("AgHBLIAAhLIAYAAIAAhKIAUAAIAAAdIAmAAIAAATIgmAAIAAAaIAhAAIAABLIgUAAIAAgHIgnAAIAAAHgAALAyIAnAAIAAggIgnAAgAhKAqIAigGQAFgYAEgkIASADQgHAhgFAUIAOgDIACASIg9AOgAhDgUIAOgDQAGAbACAZIgQAEQgBgZgFgcgAhJgcIAAgSIAcAAQgEgMgGgLIARgFQAHALAEAMIgNAFIAgAAIAAASg");
	this.shape_5.setTransform(-145.7,-6.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#424242").s().p("AgLBMIAAg6IgNAGIgCgHQgiAGgGACIgGgPQAFgBAIgJIAKgOQgOABgEACIgGgPQAFgCAEgHQAKgPAJgZIAPAHQgKAYgLAPIALAAIAMgXIAOAJQgOAagTAXIARgCIgEgKIANgFIAKAcIAAhVIBVAAIAAB9QAAAMgGADQgFADgSAAQgBgIgDgIIAOAAQAAAAABAAQAAAAABAAQAAgBAAAAQAAgBAAAAIAAhsIg0AAIAAB/gAhJBEQAEgOACgXIAOACQgCAagFANQgFgDgIgBgAgxAhIAMgEQADARABARIgNAEgAggAdIALgEQAHARADANIgNAFQgCgOgGgRgAAeAuQgKAAgDgFQgDgDAAgLIAAgJIgFAAIAAgPIAQAAIgEgJIAKgDIgXAAIAAgPIAJAAQgBgJgFgMIALgDQAFAJACAMIgKADIAPAAIAFgYIANAEIgGAUIAIAAIAAAPIgTAAQAEAIABACIgHACIAUAAIAAAPIgYAAIAAAKQAAAFADAAIAVgBIABANQgCABgIAAg");
	this.shape_6.setTransform(-162.2,-6.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#424242").s().p("AABgIQgSA2gpAZQgGgHgLgJQAvgYAPhCIAKACIgDgSIglAAIAAgTIA4AAQAABWBAAmQgLAJgFAIQgsgagQg1g");
	this.shape_7.setTransform(-178.2,-6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#424242").s().p("AhNA6QAJgLAIgFQAGgNAEgPIgVAAIAMgjIgPAAIAAgRIAmAAIgLAkIAHAAIADgBIAIADQgFAYgIARIAKAHQANAIAfAAQAhAAAhgFQgGAPAAAFIg9ADQgegBgQgIQgMgJgDAAQgFAAgJAUgAgTAyIAAhDIgJAJIgKgSQAVgTAKgeIARAFQgDAJgGAMIAYAAQgDgKgFgIIASgFQAIAMADALIAZAAIAAAQIggAAIAAAJIAaAAIAAAPIgaAAIAAAKIAZAAIAAAPIgZAAIAAAKIAiAAIAAAQIhKAAIAAAIgAgBAaIAVAAIAAgKIgVAAgAgBABIAVAAIAAgKIgVAAgAgBgYIAVAAIAAgJIgVAAgAhBhGIARgFIAJAaIgSAHIgIgcg");
	this.shape_8.setTransform(-194.4,-6.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F3255D").s().p("AoaizIL9mmIE4JjIw1JQg");
	this.shape_9.setTransform(148.4,21.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F6496F").s().p("Ar8ABIL8mmIL9GlIr9Gmg");
	this.shape_10.setTransform(94.5,-39.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FA5E79").s().p("AoZAJIE4phIL7GkIAAMNg");
	this.shape_11.setTransform(40.7,21.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FA5E79").s().p("Aw0DcIE4phIL8mnIL8GmIE5JjIw1JQg");
	this.shape_12.setTransform(94.6,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.boxred, new cjs.Rectangle(-202.2,-81.2,404.5,162.6), null);


(lib.boxblue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ao7AFIAAgJIR3AAIAAAJg");
	this.shape.setTransform(-2.7,-8.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#424242").s().p("AguBHIBMiNIAQAAIhLCNgAAaBCQgGgCgDgEQgEgFAAgGIgBgQIABgQQAAgHAEgFQADgEAGgBQAGgDAIAAQAJAAAFADQAHABACAEQADADACAJIAAAgQgCAHgDAEQgCAEgHACQgEACgKAAQgJAAgFgCgAAhAQIgBAQIABARQACAFAFAAQAHAAAAgFQACgFAAgMQAAgKgCgGQgBgFgGAAQgFAAgCAFgAg2ACQgFgCgDgDQgDgFgBgHIAAggQABgGADgFQADgEAFgDQAGgCAJAAQAJAAAFACQAHADACAEQADAFABAGQABAHAAAJQAAAKgBAGQgBAHgDAFQgCADgHACQgFACgJAAQgJAAgGgCgAgugvQgCAGABAKQgBALACAFQACAGAFAAQAGAAABgGQABgDAAgNIgBgQQgBgFgGAAQgFAAgCAFg");
	this.shape_1.setTransform(-76.6,-7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#424242").s().p("AgTBBQgIgEgGgHQgFgKgBgLQgCgKAAgTIABgbQABgNAEgKQAFgJAHgGQAJgGAOAAQANAAAHADQAJAEAEAIQAFAHACANQACAKAAAUIgBAaQgBALgEAMQgFAKgHAGQgKAFgOAAQgLAAgIgDgAgHgvQgDACgBAFIgCAOIAAA4IACAMQACAFADACQADACADAAQAEAAAEgCQACgDACgFIACgNIAAg5IgDgMQgBgFgDgCQgCgCgFABQgDAAgEACg");
	this.shape_2.setTransform(-88.5,-6.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#424242").s().p("AAABDIAAheIgaAAIAAgSIADAAQANAAAIgEQAHgGACgLIAUAAIAACFg");
	this.shape_3.setTransform(-98.6,-7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#424242").s().p("AgQA7QAIgFgBgJIAAggIgFAAIAAgPIAJAAIAAhDIBJAAIAAAQIg3AAIAAAHIAvAAIAAAOIgvAAIAAAIIAwAAIAAANIgwAAIAAAJIA6AAIAAAPIgOAAIgZAAIAIAOIARgOIANAMIgVAOQAMANAOAFQgHAFgHALQgfgQgQgsIgFAAIAAAnIAWgGIABAPQgjAMgEADQgDgIgGgJgAg1BLIAAhoIgGAAIAABHIgPAAIAAhXIAVAAIAAgeIAPAAIAAAeIAWAAIAABEQAAAKgFADQgEAEgIAAQgCgIgDgHIAAAygAgmAYIAHAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAgzIgHAAg");
	this.shape_4.setTransform(-113.7,-6.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#424242").s().p("AgDBMIAAhBIBHAAIAABBIgTAAIAAgHIgjAAIAAAHgAAOA0IAjAAIAAgYIgjAAgAhKBFQAFgMACgaIAPADQgBAVgGATgAgwAhIAOgCQAEAVAAAQIgOACQgBgTgDgSgAgfAeIANgEQAHAUACAMIgNAEQgCgJgHgXgAhJAJQAFgBAIgIIAKgOQgPACgDACIgGgRQAEAAAFgIQAMgRAIgXIARAHQgJAVgNASIALgBQAIgMADgIIAQAKQgQAbgSASIARgBIgEgMIAOgEQAIASACAPIgOAFIgCgIQglAFgFADIgGgRgAgGAAIAAgSIAbAAIAAgTIggAAIAAgRIAgAAIAAgUIAUAAIAAAUIAiAAIAAARIgiAAIAAATIAfAAIAAASg");
	this.shape_5.setTransform(-130.3,-6.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#5DB9C0").s().p("Aj2hRIFdjCICQEYIntEPg");
	this.shape_6.setTransform(113.2,9.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#69CDD6").s().p("AldABIFdjCIFeDBIleDBg");
	this.shape_7.setTransform(88.5,-17.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#85D6E1").s().p("Aj1AEICPkWIFdDAIAAFlg");
	this.shape_8.setTransform(63.8,9.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#85D6E1").s().p("AnsBlICPkWIFdjDIFeDCICQEXInuEPg");
	this.shape_9.setTransform(88.5,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.boxblue, new cjs.Rectangle(-137.8,-37.2,275.7,74.5), null);


(lib.body = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0E0E0").s().p("AmbCEQiqipAAjxIAAgYQAFDoClClQCrCqDwAAQDxAACqiqQCmilAFjoIAAAYQAADxirCpQiqCqjxAAQjwAAiriqg");
	this.shape.setTransform(-22.8,86.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1BB482").s().p("AAAAwQgjgBgZgZQgagZABgkIAAgIQAEAgAYAVQAYAWAhABQAhAAAZgWQAYgVAEghIAAAKQAAAkgaAYQgZAZgiAAIgBAAg");
	this.shape_1.setTransform(-22.2,-103.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#20CA9A").s().p("AgzASIAAgjIBnAAIAAAjg");
	this.shape_2.setTransform(-27.4,49.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#20CA9A").s().p("AhEASIAAgjICJAAIAAAjg");
	this.shape_3.setTransform(-29.1,43.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#20CA9A").s().p("AhVASIAAgjICrAAIAAAjg");
	this.shape_4.setTransform(-30.8,36.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#20CA9A").s().p("AhzEBQgNAAgPgIQgOgJgHgLIh0jIQgGgMAAgRQAAgQAGgMIB0jHQAGgMAPgJQAPgIANAAIDmAAQAOAAAOAIQAPAJAHAMIBzDHQAHAMAAAQQAAARgHAMIhzDIQgHALgPAJQgOAIgOAAgAh1jLQgGADgCADIhsC8QgCAEAAAFQAAAHACADIBsC8QACADAGADQAFAEAEAAIDYAAQAEAAAGgEQAFgDACgDIBti8QACgDAAgHQAAgFgCgEIhti8QgCgDgFgDQgGgDgEAAIjYAAQgDAAgGADg");
	this.shape_5.setTransform(-22.2,34.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E0E0E0").s().p("AgzASIAAgjIBnAAIAAAjg");
	this.shape_6.setTransform(-27.4,50.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E0E0E0").s().p("AhEASIAAgjICJAAIAAAjg");
	this.shape_7.setTransform(-29.1,44.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E0E0E0").s().p("AhVASIAAgjICrAAIAAAjg");
	this.shape_8.setTransform(-30.8,37.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E0E0E0").s().p("AhzEBQgNAAgPgIQgOgJgHgLIh0jIQgGgMAAgRQAAgQAGgMIB0jIQAHgLAOgJQAPgIANAAIDmAAQAOAAAOAIQAPAJAHALIBzDIQAHAMAAAQQAAARgHAMIhzDIQgHALgPAJQgOAIgOAAgAh1jLQgGADgCADIhsC8QgCADAAAGQAAAHACADIBsC8QACADAGADQAFAEAEAAIDYAAQAEAAAGgEQAFgDACgDIBti8QACgDAAgHQAAgGgCgDIhti8QgCgDgFgDQgGgEgEAAIjYAAQgEAAgFAEg");
	this.shape_9.setTransform(-22.2,35.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#20CA9A").s().p("AAABWQgjAAgZgaQgagZABgjQAAgkAagZQAZgZAjABQAkAAAZAaQAZAZgBAjQAAAjgaAaQgZAYgiAAIgBAAg");
	this.shape_10.setTransform(-22.2,-107.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#757575").s().p("AgNBhIACjBIAZAAIgCDBg");
	this.shape_11.setTransform(-22.2,-95.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BDBDBD").s().p("AgfiHQAOAAAMADIAlD8QgdAQgiAAg");
	this.shape_12.setTransform(38.5,-17.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E0E0E0").s().p("AhhAQQgHAAgKgEQgGgGgEgKIgEgLQAEAJAJAFQAIAFAKAAIDCAAQAWAAAJgTIABAAQgFARgKAKQgJAEgIAAg");
	this.shape_13.setTransform(-22.8,-76.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhhBNQgNAAgLgIQgMgHgFgMIg6h6IAMgEIA5B5QADAJAJAFQAIAGAKAAIDCAAQAXAAAJgUIA4h5IALAEIg4B6QgGAMgLAHQgMAIgOAAg");
	this.shape_14.setTransform(-22.8,-82.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#424242").s().p("AksCnQh9hFAAhiQAAhhB9hFQB9hFCvAAQCxAAB8BFQB9BFAABhQAABih9BFQh8BFixAAQivAAh9hFg");
	this.shape_15.setTransform(-22.9,-41.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E0E0E0").s().p("AksCnQh9hFAAhiQAAhhB9hFQB9hGCvAAQCxAAB8BGQB9BFAABhQAABih9BFQh8BGixAAQivAAh9hGg");
	this.shape_16.setTransform(-22.9,-44);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#E0E0E0").s().p("AksCnQh9hFAAhiQAAhhB9hFQB9hFCvAAQCxAAB8BFQB9BFAABhQAABih9BFQh8BFixAAQivAAh9hFg");
	this.shape_17.setTransform(-22.9,-38.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E0E0E0").s().p("AhDiGQA4AAAnAnQAoAoAAA3QAAA4goAoQgnAog4AAg");
	this.shape_18.setTransform(42.1,-17.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E0E0E0").s().p("AgbBgQgogoAAg4QAAg3AogoQAmgnA5AAIAAEOQg5AAgmgog");
	this.shape_19.setTransform(-87.8,-17.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F2F2F2").s().p("AmbNvQiqiqAAjxIAAunQAAjxCqiqQCrirDwAAQDxAACqCrQCrCqAADxIAAOnQAADxirCqQiqCqjxAAQjwAAiriqg");
	this.shape_20.setTransform(-22.8,11.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F7EFEB").s().p("AghA3QgIgEgDgHIgSguQgCgIADgIQADgHAIgDIBFgbQAIgCAIADQAHADADAIIASAuQADAIgEAHQgDAIgIADIhFAaIgHACQgFAAgDgCg");
	this.shape_21.setTransform(74.7,80.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#616161").s().p("AgQAAIAegKIADAKIgdALg");
	this.shape_22.setTransform(71.1,70.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#616161").s().p("AgQABIAegLIADAKIgdALg");
	this.shape_23.setTransform(68.9,65.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#616161").s().p("AgRABIAfgLIADAKIgdALg");
	this.shape_24.setTransform(66.7,59.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#616161").s().p("AgQABIAdgLIAFAKIgfALg");
	this.shape_25.setTransform(64.5,53.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#616161").s().p("AgQAAIAdgKIAEAKIgeALg");
	this.shape_26.setTransform(62.3,47.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgeALg");
	this.shape_27.setTransform(60.1,41.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgeALg");
	this.shape_28.setTransform(57.9,36);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgeALg");
	this.shape_29.setTransform(55.7,30.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_30.setTransform(53.5,24.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_31.setTransform(51.3,18.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#616161").s().p("AgQAAIAdgKIAEAKIgdALg");
	this.shape_32.setTransform(49.1,12.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_33.setTransform(46.9,6.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#757575").s().p("AjDnZIAfgLIFoO+IgfALg");
	this.shape_34.setTransform(56.6,32.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#BDBDBD").s().p("AgRgDQAKgNAHgHIASAkIgJALg");
	this.shape_35.setTransform(68.9,83.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#20CA9A").s().p("AhCCRQg3gbgVg5QgXg9Acg6QAcg7A+gUQA2gTA3AYQA2AYAYA1QANAeAAAfQABAfgNAdQgEAKgKABQgKACgHgIQgIgJAEgKQASgrgQgpQgRgugtgTQgtgUgsATQgrARgTAtQgSArARArQAQAqAoATQALAFAAALQAAALgJAGQgFADgFAAQgEAAgEgCg");
	this.shape_36.setTransform(79.3,91.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.body, new cjs.Rectangle(-94.6,-116.3,189.2,232.6), null);


(lib.armbox = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F7EFEB").s().p("AgYA5QgJAAgFgGQgGgFAAgIIAAhLQAAgIAGgGQAGgGAIABIAxAAQAJAAAFAGQAGAGAAAIIAABKQAAAIgGAGQgGAGgIAAg");
	this.shape.setTransform(12.7,7.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#616161").s().p("AgEARIAAggIAKAAIAAAgg");
	this.shape_1.setTransform(22.9,7.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#616161").s().p("AgFAQIAAgfIAKAAIAAAfg");
	this.shape_2.setTransform(29.1,7.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#616161").s().p("AgEAQIAAgfIAJAAIAAAfg");
	this.shape_3.setTransform(35.3,7.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#616161").s().p("AgFAQIAAgfIALAAIAAAfg");
	this.shape_4.setTransform(41.6,7.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#616161").s().p("AgFAQIAAggIAKAAIAAAhg");
	this.shape_5.setTransform(47.8,7.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#616161").s().p("AgEARIAAghIAKAAIAAAhg");
	this.shape_6.setTransform(54,7.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#616161").s().p("AgEAQIAAgfIAKAAIAAAfg");
	this.shape_7.setTransform(60.2,7.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#616161").s().p("AgFAQIAAgfIAKAAIAAAfg");
	this.shape_8.setTransform(66.5,7.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#616161").s().p("AgEAQIAAgfIAJAAIAAAfg");
	this.shape_9.setTransform(72.7,7.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#616161").s().p("AgFAQIAAgfIALAAIAAAfg");
	this.shape_10.setTransform(78.9,7.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#616161").s().p("AgFARIAAghIAKAAIAAAhg");
	this.shape_11.setTransform(85.1,7.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#616161").s().p("AgEARIAAghIAKAAIAAAhg");
	this.shape_12.setTransform(91.4,7.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#757575").s().p("AoAAPIABggIP/ADIAAAgg");
	this.shape_13.setTransform(63.9,7.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BDBDBD").s().p("AgXgBIAIgMIAnADQgFAMgHAMg");
	this.shape_14.setTransform(11.5,13.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#20CA9A").s().p("AgVBPQg8AAgtgqQgHgHACgKQACgKAKgEQAMgEAIAIQAgAfAsABQAuAAAjggQAjggABgvIAmgKQADBCguAuQgtAvg/AAIgCgBg");
	this.shape_15.setTransform(1.8,14.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#4549BA").s().p("AkohiIGljpICsFRIpRFFg");
	this.shape_16.setTransform(-26.2,11.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#5D61DE").s().p("AmkABIGkjpIGlDoImlDpg");
	this.shape_17.setTransform(-55.9,-21.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#6C69EA").s().p("AknAFICrlPIGkDoIAAGtg");
	this.shape_18.setTransform(-85.5,11.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#6C69EA").s().p("ApQB5ICrlPIGljpIGlDpICsFQIpRFGg");
	this.shape_19.setTransform(-55.8,0);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#20CA9A").s().p("AA+gFQgigjgwAAQgtAAgiAgQgJAHgKgEQgKgDgCgKQgDgLAIgHQAXgVAdgLQAegLAhACQA5AEApAqQAqAqACA6IgmAJQACgwgigjg");
	this.shape_20.setTransform(1.8,-0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.armbox, new cjs.Rectangle(-115.1,-44.7,230.3,89.6), null);


// stage content:
(lib.animate = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// box-top
	this.instance = new lib.boxtop();
	this.instance.parent = this;
	this.instance.setTransform(271.7,57.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:58.8},0).wait(1).to({y:60},0).wait(1).to({y:61.1},0).wait(1).to({y:62.2},0).wait(1).to({y:63.1},0).wait(1).to({y:64},0).wait(1).to({y:64.9},0).wait(1).to({y:65.6},0).wait(1).to({y:66.3},0).wait(1).to({y:66.8},0).wait(1).to({y:67},0).wait(1).to({y:66.5},0).wait(1).to({y:66.1},0).wait(1).to({y:65.5},0).wait(1).to({y:64.9},0).wait(1).to({y:64.2},0).wait(1).to({y:63.5},0).wait(1).to({y:62.7},0).wait(1).to({y:61.8},0).wait(1).to({y:60.8},0).wait(1).to({y:59.8},0).wait(1).to({y:58.7},0).wait(1).to({y:57.6},0).wait(1));

	// box-blue
	this.instance_1 = new lib.boxblue();
	this.instance_1.parent = this;
	this.instance_1.setTransform(249.3,116);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({y:117.9},0).wait(1).to({y:119.8},0).wait(1).to({y:121.6},0).wait(1).to({y:123.2},0).wait(1).to({y:124.7},0).wait(1).to({y:125.3},0).wait(1).to({y:124.7},0).wait(1).to({y:124.2},0).wait(1).to({y:123.8},0).wait(1).to({y:123.4},0).wait(1).to({y:123},0).wait(1).to({y:122.7},0).wait(1).to({y:122.3},0).wait(1).to({y:121.9},0).wait(1).to({y:121.5},0).wait(1).to({y:121},0).wait(1).to({y:120.4},0).wait(1).to({y:119.8},0).wait(1).to({y:119.1},0).wait(1).to({y:118.4},0).wait(1).to({y:117.6},0).wait(1).to({y:116.8},0).wait(1).to({y:116},0).wait(1));

	// text
	this.instance_2 = new lib.text();
	this.instance_2.parent = this;
	this.instance_2.setTransform(196.9,168);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(7).to({_off:false},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:1},0).wait(4).to({alpha:0.9},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0},0).wait(1));

	// wave
	this.instance_3 = new lib.wave();
	this.instance_3.parent = this;
	this.instance_3.setTransform(562.1,70.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({y:69.7,alpha:0.955},0).wait(1).to({y:68.9,alpha:0.909},0).wait(1).to({y:68.1,alpha:0.864},0).wait(1).to({y:67.4,alpha:0.818},0).wait(1).to({y:66.8,alpha:0.773},0).wait(1).to({y:66.1,alpha:0.727},0).wait(1).to({y:65.6,alpha:0.682},0).wait(1).to({y:65.1,alpha:0.636},0).wait(1).to({y:64.6,alpha:0.591},0).wait(1).to({y:64.2,alpha:0.545},0).wait(1).to({y:64.1,alpha:0.5},0).wait(1).to({y:64.4,alpha:0.542},0).wait(1).to({y:64.7,alpha:0.583},0).wait(1).to({y:65.1,alpha:0.625},0).wait(1).to({y:65.5,alpha:0.667},0).wait(1).to({y:66,alpha:0.708},0).wait(1).to({y:66.5,alpha:0.75},0).wait(1).to({y:67.1,alpha:0.792},0).wait(1).to({y:67.7,alpha:0.833},0).wait(1).to({y:68.3,alpha:0.875},0).wait(1).to({y:69,alpha:0.917},0).wait(1).to({y:69.8,alpha:0.958},0).wait(1).to({y:70.6,alpha:1},0).wait(1));

	// eye
	this.instance_4 = new lib.eye();
	this.instance_4.parent = this;
	this.instance_4.setTransform(562.2,154.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1).to({x:560.6,y:154.3},0).wait(1).to({x:559.1,y:153.7},0).wait(1).to({x:557.5,y:153.2},0).wait(1).to({x:556,y:152.7},0).wait(1).to({x:554.4,y:152.3},0).wait(1).to({x:552.9,y:151.9},0).wait(1).to({x:551.3,y:151.5},0).wait(1).to({x:549.8,y:151.1},0).wait(1).to({x:548.2,y:150.8},0).wait(1).to({x:546.7,y:150.5},0).wait(1).to({x:545.2},0).wait(1).to({x:546.6,y:150.7},0).wait(1).to({x:548,y:150.9},0).wait(1).to({x:549.4,y:151.2},0).wait(1).to({x:550.8,y:151.4},0).wait(1).to({x:552.2,y:151.8},0).wait(1).to({x:553.7,y:152.1},0).wait(1).to({x:555.1,y:152.5},0).wait(1).to({x:556.5,y:152.9},0).wait(1).to({x:557.9,y:153.4},0).wait(1).to({x:559.3,y:153.8},0).wait(1).to({x:560.7,y:154.4},0).wait(1).to({x:562.2,y:154.9},0).wait(1));

	// body
	this.instance_5 = new lib.body();
	this.instance_5.parent = this;
	this.instance_5.setTransform(584.4,198);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({y:197.4},0).wait(1).to({y:196.8},0).wait(1).to({y:196.3},0).wait(1).to({y:195.8},0).wait(1).to({y:195.4},0).wait(1).to({y:195},0).wait(1).to({y:194.6},0).wait(1).to({y:194.2},0).wait(1).to({y:193.9},0).wait(1).to({y:193.6},0).wait(2).to({y:193.8},0).wait(1).to({y:194},0).wait(1).to({y:194.3},0).wait(1).to({y:194.5},0).wait(1).to({y:194.9},0).wait(1).to({y:195.2},0).wait(1).to({y:195.6},0).wait(1).to({y:196},0).wait(1).to({y:196.5},0).wait(1).to({y:196.9},0).wait(1).to({y:197.5},0).wait(1).to({y:198},0).wait(1));

	// arm-box
	this.instance_6 = new lib.armbox();
	this.instance_6.parent = this;
	this.instance_6.setTransform(444.2,174.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1).to({x:439.1,y:173.8},0).wait(1).to({x:434.1,y:173.2},0).wait(1).to({x:429,y:172.6},0).wait(1).to({x:424,y:172.1},0).wait(1).to({x:418.9,y:171.6},0).wait(1).to({x:413.9,y:171.1},0).wait(1).to({x:408.8,y:170.7},0).wait(1).to({x:403.8,y:170.3},0).wait(1).to({x:398.7,y:170},0).wait(1).to({x:393.7,y:170.2},0).wait(1).to({x:397.5,y:170.4},0).wait(1).to({x:401.4,y:170.6},0).wait(1).to({x:405.3,y:170.8},0).wait(1).to({x:409.2,y:171},0).wait(1).to({x:413.1,y:171.3},0).wait(1).to({x:417,y:171.6},0).wait(1).to({x:420.9,y:171.9},0).wait(1).to({x:424.8,y:172.2},0).wait(1).to({x:428.6,y:172.6},0).wait(1).to({x:432.5,y:173},0).wait(1).to({x:436.4,y:173.5},0).wait(1).to({x:440.3,y:173.9},0).wait(1).to({x:444.2,y:174.5},0).wait(1));

	// shadow
	this.instance_7 = new lib.shadow();
	this.instance_7.parent = this;
	this.instance_7.setTransform(561.4,333.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1).to({scaleX:0.98,scaleY:0.98},0).wait(1).to({scaleX:0.96,scaleY:0.96},0).wait(1).to({scaleX:0.94,scaleY:0.94},0).wait(1).to({scaleX:0.92,scaleY:0.92},0).wait(1).to({scaleX:0.9,scaleY:0.9},0).wait(1).to({scaleX:0.88,scaleY:0.88},0).wait(1).to({scaleX:0.86,scaleY:0.86},0).wait(1).to({scaleX:0.84,scaleY:0.84},0).wait(1).to({scaleX:0.83,scaleY:0.83},0).wait(1).to({scaleX:0.81,scaleY:0.81},0).wait(1).to({scaleX:0.79,scaleY:0.79},0).wait(1).to({scaleX:0.8,scaleY:0.8},0).wait(1).to({scaleX:0.82,scaleY:0.82},0).wait(1).to({scaleX:0.84,scaleY:0.84},0).wait(1).to({scaleX:0.86,scaleY:0.86},0).wait(1).to({scaleX:0.88,scaleY:0.88},0).wait(1).to({scaleX:0.89,scaleY:0.89},0).wait(1).to({scaleX:0.91,scaleY:0.91},0).wait(1).to({scaleX:0.93,scaleY:0.93},0).wait(1).to({scaleX:0.95,scaleY:0.95},0).wait(1).to({scaleX:0.96,scaleY:0.96},0).wait(1).to({scaleX:0.98,scaleY:0.98},0).wait(1).to({scaleX:1,scaleY:1},0).wait(1));

	// box-yellow
	this.instance_8 = new lib.boxyellow();
	this.instance_8.parent = this;
	this.instance_8.setTransform(248.7,227.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({y:229.3},0).wait(1).to({y:231},0).wait(1).to({y:232.5},0).wait(1).to({y:234},0).wait(1).to({y:235.3},0).wait(1).to({y:236.5},0).wait(1).to({y:237},0).wait(1).to({y:236.4},0).wait(1).to({y:235.9},0).wait(1).to({y:235.5},0).wait(1).to({y:235.1},0).wait(1).to({y:234.8},0).wait(1).to({y:234.4},0).wait(1).to({y:234},0).wait(1).to({y:233.5},0).wait(1).to({y:233},0).wait(1).to({y:232.4},0).wait(1).to({y:231.7},0).wait(1).to({y:231},0).wait(1).to({y:230.2},0).wait(1).to({y:229.4},0).wait(1).to({y:228.5},0).wait(1).to({y:227.6},0).wait(1));

	// box-red
	this.instance_9 = new lib.boxred();
	this.instance_9.parent = this;
	this.instance_9.setTransform(243.3,298.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1).to({y:298.8},0).wait(1).to({y:299.6},0).wait(1).to({y:300.3},0).wait(1).to({y:300.9},0).wait(1).to({y:301.5},0).wait(1).to({y:302.1},0).wait(1).to({y:302.6},0).wait(1).to({y:303.1},0).wait(1).to({y:303.5},0).wait(1).to({y:303.9},0).wait(2).to({y:303.7},0).wait(1).to({y:303.4},0).wait(1).to({y:303},0).wait(1).to({y:302.7},0).wait(1).to({y:302.2},0).wait(1).to({y:301.8},0).wait(1).to({y:301.3},0).wait(1).to({y:300.7},0).wait(1).to({y:300.1},0).wait(1).to({y:299.5},0).wait(1).to({y:298.8},0).wait(1).to({y:298.1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(401.1,220.7,637.9,358.7);
// library properties:
lib.properties = {
	id: '97F7A7878B334DFF84378CAE115797CE',
	width: 720,
	height: 400,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['97F7A7878B334DFF84378CAE115797CE'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createPercentJs = createjs ||{}, AdobeAn = AdobeAn||{});
var createPercentJs, AdobeAn;