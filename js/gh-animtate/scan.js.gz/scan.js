(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.wave = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#20CA9A").s().p("AAwAdQgGgCgDgFQgMgWgaAAQgLgBgLAFQgLAGgHALQgDAFgFACQgGABgFgDQgHgEAAgIQAAgEACgDQAKgQASgKQASgKAUABQATABAQAJQAQAKAKAQQACAFgBADQAAAHgHAEQgDACgDAAIgEAAg");
	this.shape.setTransform(-0.2,5.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#20CA9A").s().p("AB9AuQgGgBgDgFQgVgagdgOQgdgPgigCQghgBgfANQggANgWAaQgEAFgGAAQgGABgEgEQgFgFAAgHQAAgEADgEQAbgeAlgQQAlgQAoABQAoACAjASQAiASAZAeQADAEgBAFQAAAHgFAEQgEADgFAAIgBAAg");
	this.shape_1.setTransform(0,-3.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#424242").s().p("ABYAlQgGAAgEgFQgbgmgwgDQgXAAgWAJQgWAKgOASQgEAFgFABQgGAAgEgDQgHgEABgIQAAgEADgEQATgXAcgNQAbgNAeACQAdABAaAOQAZAOARAXQADADAAAFQAAAHgGAEQgEADgDAAIgDgBg");
	this.shape_2.setTransform(-0.1,0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.wave, new cjs.Rectangle(-14,-8.1,28.1,16.3), null);


(lib.text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOBGQgGgFAAgJQAAgIAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAIQAAAJgGAFQgGAGgJAAQgIAAgGgGgAgJAXIgIhEIAAgeIAjAAIgIBig");
	this.shape.setTransform(71.1,15.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAGBaIAAhAIAhAAQgOgKgLgLIgiAAQgMANgMAIIAlAAIAAA+IgXAAIAAgEIgVAAIAAAGIgWAAIAAgwIgJAEQgDgKgJgIQAZgKARgNIgmAAIAAgTIA8AAQAGgIAEgJIg5AAIAAg5IBEAAIAAA3IAOACIgIARIApAAIgSgJIAIgIIgWAAIAAg5IBHAAIAAA5IgiAAQALAFAIAGIgFAGIAhAAIAAATIgtAAQAUAOAeAIQgHAFgIAOIgGgCIAAAsIgXAAIAAgEIgYAAIAAAGgAAbBAIAYAAIAAgRIgYAAgAgzBAIAVAAIAAgRIgVAAgAAcgzIAaAAIAAgSIgaAAgAg4gzIAZAAIAAgSIgZAAg");
	this.shape_1.setTransform(56.2,15.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AACBSIAAALIgSAAIAAhTIgIAKIgFgIIAAAMIgPAAIAAAbIASgEIACATIhCARIgFgWIAIgBIAAhBIARAAIAAA9IAHgBIAAhKIgXAAIAAhCIA4AAIAAAeQAQgTAHgSIASAGQgNAfgVAUIgHgJIAAAZIgOAAIAAAXIAJAAQAUgVAJggIASAGIgKAXIAABlQAOgTAAg8IAUAAIgDAeQAFAVAHAIIAAhLIALAAQgHgIgHgFQASgTACguIATABQgCASgDAPQAOASAFANIgMAOIgOgXQgEANgJAJIAJAAIAAAdIAYAAIAAAUIgYAAIAAAkIAdAAQgCAFgDAPIgXAAQgNAAgJgFQgKgFgHgOQgEAQgJAKQgHgHgFgEgAhEgnIASAAIAAgaIgSAAgAAHgYQAPgVAEgvIATACIgFAcIAMANIgLAUIgFgMQgGATgJAMQgHgJgHgFg");
	this.shape_2.setTransform(36.2,15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AheBHQAMgPAMgGQAIgQAEgSIgaAAQAHgRAHgYIgVAAIAAgVIAxAAIgOArIAMAAIADgBIAKAEQgHAegMAXIAKAHQAPAJAnAAQAsAAAlgFQgGANgBALQgpADgiAAQgmAAgSgLQgQgLgEAAQgGAAgKAZgAgWA4IAAiBIAfAAIAFgUIAcADIgHARIAmAAIAAA4IhJAAIAAANIBRAAIAAA8gAAAAkIA6AAIAAgWIg6AAgAAAglIAyAAIAAgRIgyAAgAhQhUIAWgHIAMAhIgXAHg");
	this.shape_3.setTransform(16.1,15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAKA/IAQgOIg0AAIARANQgcAQglALIgQgTQAggHAZgOIghAAIAAhnIAzAAIACgMIhGAAIAAgWICmAAIAAAWIhFAAIgFAMIA8AAIAABnIgmAAQAiAMAaAMIgXAQQgYgOgigMgAgpAeIBUAAIAAgLIhUAAgAgpACIBUAAIAAgKIhUAAgAgpgZIBUAAIAAgLIhUAAg");
	this.shape_4.setTransform(-3.9,15.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgOBeIAAhHIgQAHIgCgJQgrAIgHADQgCgLgFgIQAGgCAKgLIAMgSQgRABgFAEQgDgNgEgGQAFgCAGgKQAMgPALghIATAIQgLAYgPAYIAOgBIAOgcIARALQgTAlgWAYIAWgCIgFgNIAQgFQAJAUADAOIAAhpIBqAAIAACaQAAAPgIAEQgHAEgVAAQgCgLgEgJIARAAQABAAABAAQAAAAABgBQAAAAABgBQAAAAAAgBIAAiGIhBAAIAACegAhbBUQAGgRACgdIARADQgBAdgHATQgGgDgLgCgAg9ApIAPgFQAFAZABARIgRAEQgBgRgDgYgAgoAjIAOgEQAIASAEATIgQAGQgCgNgIgagAAlA5QgMgBgEgFQgEgFAAgMIAAgMIgGAAIAAgRIAUAAIgFgNIAMgDIgcAAIAAgSIALAAQgBgLgHgPIAOgEQAGANACAMIgLAFIARAAQAGgRABgNIAQAEIgIAaIALAAIAAASIgYAAQAFAHABAFIgIAEIAZAAIAAARIgeAAIAAAMQAAAGADABIAOAAQAIgBAEgBIABAQQgCACgKAAg");
	this.shape_5.setTransform(-24.2,15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhdBKQAdgSAIgrIAXAEIgEASQAIASAUAHIAAgzIhOAAIAAgUICwAAIAAAUIhKAAIAAAPIA+AAIAAAVIg+AAIAAATIBQAAQgGAKgCANIg6AAQgdAAgQgGQgUgGgLgQQgMAUgQALQgJgKgJgGgAhEgUIAAhFICKAAIAABFgAgtgkIBbAAIAAgLIhbAAgAgtg+IBbAAIAAgLIhbAAg");
	this.shape_6.setTransform(-43.9,15.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAeA9QgQAOgUALQgGgLgKgIQAWgLAWgSQgGgWgEgeIgoAAIAAAWIAegGIACAWIggAGIAAAiQAAASgLAGQgJAEgbAAQgBgKgHgOQAUABAGgBQAFAAAAgEIAAgdIgkAHIgFgYIApgGIAAgaIgmAAIAAgXIAmAAIAAgXIggAFQgBgLgGgJQAzgIAdgJIAPAUIggAIIAAAbIAmAAQgDgeAAgZIAZAAQAAAYACAfIA3AAIAAAXIg0AAIAFAhQALgNAIgOIAVAIQgNAYgUAUQAJAZAJAAQAGAAABghQAKAJAKAEQgDAagGAJQgGAJgOAAQgVAAgOgggAAnhMIASgMQAUAQAKAQIgTANQgJgQgUgRg");
	this.shape_7.setTransform(-63.8,15.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgIAJQgHgIgGgCQgGgEgLAAQgSAAgNAXIgXgMQAUgkAjAAQAbAAATAWQANAOARAAQATAAANgXIAWAMQgTAkgjAAQgbAAgUgWg");
	this.shape_8.setTransform(-43.9,-15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAiBdQAAgLgGgIIATABQAFAAACgEQACgCAAgDIg+AAQAEgTADgYIgKAAIAAgUIAMAAIAFgiIgIAMQgGgJgJgIQARgUAIgkIAUAEIgEASIA/AAIAAAWIhIAAIgHANIBJAAIgBAmIAJAAIAAAUIgKAAIgBAXIAJAAIAAAUIgMAAQgCANgEAFQgFAHgKABIgLABIgLAAgAA4AnIgIAHIALAAIADgXIgYAAQAMAKAGAGgAASAuIAXAAQgJgIgJgGIAJgJIgLAAgAA8gCIgGAFIAJAAIABgTIgUAAQAIAFAIAJgAAXADIAVAAQgIgHgIgFIAHgHIgIAAgAgyBSQAOgfAJghIASALQgHAbgOAkgAhZA8IAAiHIAuAAIAAA2IAJgNQASAHALAJIgMARQgHgGgTgLIAAA7IgdAAIAAATgAhIATIALAAIAAhIIgLAAgAgrhHIAMgPQARAIALAKIgMAQQgLgKgRgJg");
	this.shape_9.setTransform(-63.6,-15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text, new cjs.Rectangle(-73.2,-24.3,146.4,48.8), null);


(lib.shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AjsAnQhjgQAAgXQAAgWBjgQQBigRCKAAQCLAABjARQBiAQAAAWQAAAXhiAQQhjARiLAAQiJAAhjgRg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(-33.5,-5.5,67.1,11.1), null);


(lib.scan3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#33CC99","rgba(51,204,153,0)"],[0,0.702],0,0,0,0,0,100.9).s().p("AkANMQhLgWhEgqQibhgg7idQg8idBFiCQAUgmAcgdIOpvpQAigjA4AAQAtAAAqAYQAwAcAWAtQAWAtgNAqImRUhQgLAigQAdQgvBQhXAtQhTAqhpAAQhIAAhHgUg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.scan3, new cjs.Rectangle(-64.1,-86.4,128.4,172.9), null);


(lib.element1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#20CA9A").p("AAKAAQAAAKgKAAQgDAAgDgDQgDgDAAgEQAAgDADgDQADgDADAAQAEAAADADQADADAAADg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.element1, new cjs.Rectangle(-1.9,-1.9,4,4), null);


(lib.e8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#20CA9A").p("AAcAAIg8giIAABFg");
	this.shape.setTransform(-0.1,0,1,1,0,0,0,-0.4,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e8, new cjs.Rectangle(-4,-4.5,8.1,9), null);


(lib.e7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#20CA9A").p("AA4AAQAAAYgQAQQgRAQgXAAQgWAAgRgQQgQgQAAgYQAAgWAQgQQARgRAWAAQAXAAARARQAQAQAAAWg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e7, new cjs.Rectangle(-6.6,-6.6,13.2,14.4), null);


(lib.e5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#20CA9A").p("AAHgnIAhAuIguAhIghgug");
	this.shape.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e5, new cjs.Rectangle(-4.9,-5,10,10), null);


(lib.e4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#20CA9A").p("AAOAcIgpgOIAOgpIApAOg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e4, new cjs.Rectangle(-3.7,-3.7,7.6,7.6), null);


(lib.e3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#20CA9A").p("AASARIgIgfIgXAWg");
	this.shape.setTransform(-0.2,-0.2,1,1,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e3, new cjs.Rectangle(-2.6,-2.6,5.3,5.2), null);


(lib.e2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#20CA9A").p("AAXAAQAAAJgHAHQgGAHgKAAQgIAAgHgHQgHgHAAgJQAAgJAHgGQAHgHAIAAQAKAAAGAHQAHAGAAAJg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e2, new cjs.Rectangle(-3.3,-3.3,6.6,6.6), null);


(lib.body = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#20CA9A").s().p("AgKALQgFgFAAgGQAAgGAFgFQAEgEAGAAQAHAAAEAEQAFAFAAAGQAAAHgFAEQgEAFgHAAQgGAAgEgFg");
	this.shape.setTransform(-34.5,-43.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#20CA9A").s().p("AgKALQgFgFAAgGQAAgGAFgEQAEgFAGAAQAHAAAFAFQAEAEAAAGQAAAHgEAEQgFAFgHAAQgGAAgEgFg");
	this.shape_1.setTransform(-28.4,-49.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#20CA9A").s().p("AgKALQgFgEAAgHQAAgGAFgFQAEgEAGAAQAHAAAFAEQAEAFAAAGQAAAHgEAEQgFAFgHAAQgFAAgFgFg");
	this.shape_2.setTransform(-28.4,-43.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#20CA9A").s().p("AgKALQgFgEAAgHQAAgFAFgFQAFgFAFAAQAHAAAFAFQAEAEAAAGQAAAHgEAEQgFAFgHAAQgFAAgFgFg");
	this.shape_3.setTransform(-28.4,-36.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#20CA9A").s().p("AgLAMQgEgFAAgHQAAgGAEgEQAGgFAFAAQAHAAAFAFQAEAEAAAGQAAAHgEAFQgFAEgHAAQgFAAgGgEg");
	this.shape_4.setTransform(-22.2,-55.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#20CA9A").s().p("AgLALQgEgEAAgHQAAgGAEgEQAGgFAFAAQAHAAAFAFQAEAEAAAGQAAAHgEAEQgFAFgHAAQgFAAgGgFg");
	this.shape_5.setTransform(-22.2,-49.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#20CA9A").s().p("AgLALQgEgEAAgHQAAgGAEgFQAGgEAFAAQAHAAAFAEQAEAFAAAGQAAAHgEAEQgFAFgHAAQgFAAgGgFg");
	this.shape_6.setTransform(-22.2,-43.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#20CA9A").s().p("AgLALQgEgEAAgHQAAgGAEgEQAGgFAFAAQAHAAAFAFQAEAEAAAGQAAAHgEAEQgFAFgHAAQgFAAgGgFg");
	this.shape_7.setTransform(-22.2,-36.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#20CA9A").s().p("AgLAMQgEgFAAgHQAAgFAEgGQAGgEAFAAQAHAAAFAEQAEAGAAAFQAAAHgEAFQgFAEgHAAQgFAAgGgEg");
	this.shape_8.setTransform(-22.2,-30.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#20CA9A").s().p("AgLALQgEgEAAgHQAAgGAEgEQAFgFAGAAQAHAAAEAFQAFAEAAAGQAAAGgFAFQgEAFgHAAQgGAAgFgFg");
	this.shape_9.setTransform(-16,-49.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#20CA9A").s().p("AgLALQgEgEAAgHQAAgGAEgFQAFgEAGAAQAHAAAEAEQAFAFAAAGQAAAHgFAEQgEAFgHAAQgGAAgFgFg");
	this.shape_10.setTransform(-16,-43.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#20CA9A").s().p("AgLALQgEgEAAgHQAAgGAEgEQAFgFAGAAQAHAAAEAFQAFAFAAAFQAAAHgFAEQgFAFgGAAQgGAAgFgFg");
	this.shape_11.setTransform(-16,-36.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#20CA9A").s().p("AgKALQgFgEAAgHQAAgGAFgFQAEgEAGAAQAHAAAFAEQAEAFAAAGQAAAHgEAEQgFAFgHAAQgFAAgFgFg");
	this.shape_12.setTransform(-9.9,-43.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1BB482").s().p("AAAAwQgkgBgZgZQgZgZABgkIAAgIQAEAgAYAVQAYAWAhABQAgAAAZgWQAZgUADgiIABAKQgBAkgZAYQgZAZgjAAIAAAAg");
	this.shape_13.setTransform(-22.2,-103.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#20CA9A").s().p("AgzASIAAgjIBnAAIAAAjg");
	this.shape_14.setTransform(-27.4,49.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#20CA9A").s().p("AhEASIAAgjICJAAIAAAjg");
	this.shape_15.setTransform(-29.1,43.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#20CA9A").s().p("AhVASIAAgjICrAAIAAAjg");
	this.shape_16.setTransform(-30.8,36.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#20CA9A").s().p("AhzEBQgNAAgPgIQgOgJgHgLIh0jIQgGgMAAgRQAAgQAGgMIB0jHQAGgMAPgJQAPgIANAAIDmAAQAOAAAOAIQAPAJAHAMIBzDHQAHAMAAAQQAAARgHAMIhzDIQgHALgPAJQgOAIgOAAgAh1jLQgGADgCADIhsC8QgCAEAAAFQAAAHACADIBsC8QACADAGADQAFAEAEAAIDYAAQAEAAAGgEQAFgDACgDIBti8QACgDAAgHQAAgFgCgEIhti8QgCgDgFgDQgGgDgEAAIjYAAQgDAAgGADg");
	this.shape_17.setTransform(-22.2,34.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E0E0E0").s().p("AgzASIAAgjIBnAAIAAAjg");
	this.shape_18.setTransform(-27.4,50.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E0E0E0").s().p("AhEASIAAgjICJAAIAAAjg");
	this.shape_19.setTransform(-29.1,44.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#E0E0E0").s().p("AhVASIAAgjICrAAIAAAjg");
	this.shape_20.setTransform(-30.8,37.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#E0E0E0").s().p("AhzEBQgNAAgPgIQgPgJgGgMIh0jHQgGgMAAgRQAAgQAGgMIB0jIQAHgLAOgJQAPgIANAAIDmAAQAOAAAOAIQAPAJAHALIBzDIQAHAMAAAQQAAARgHAMIhzDHQgHAMgPAJQgOAIgOAAgAh1jLQgGADgCADIhsC8QgCADAAAGQAAAHACADIBsC8QACADAGADQAGAEADAAIDYAAQAEAAAGgEQAFgDACgDIBti8QACgDAAgHQAAgGgCgDIhti8QgCgDgFgDQgGgEgEAAIjYAAQgEAAgFAEg");
	this.shape_21.setTransform(-22.2,35.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#20CA9A").s().p("AAABWQgkAAgYgaQgZgZAAgjQABgkAZgZQAagZAiABQAkAAAYAaQAaAZgBAjQAAAjgaAaQgZAYgjAAIAAAAg");
	this.shape_22.setTransform(-22.2,-107.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#757575").s().p("AgNBhIACjBIAYAAIgBDBg");
	this.shape_23.setTransform(-22.2,-95.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#BDBDBD").s().p("AgfiHQAOAAAMADIAlD8QgdAQgiAAg");
	this.shape_24.setTransform(38.6,-17.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#E0E0E0").s().p("AhhAQQgHAAgKgDQgGgHgEgKIgEgLQAEAJAJAFQAIAFAKAAIDCAAQAWAAAJgTIABAAQgFARgKALQgIADgJAAg");
	this.shape_25.setTransform(-22.8,-76.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AhgBNQgOAAgLgIQgMgHgFgMIg5h6IALgEIA4B5QAEAJAJAFQAJAGAKAAIDBAAQAXAAAJgUIA4h5IALAEIg4B6QgFAMgMAHQgMAIgOAAg");
	this.shape_26.setTransform(-22.8,-82.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#424242").s().p("AksCnQh9hFAAhiQAAhhB9hFQB9hFCvAAQCxAAB9BFQB8BFAABhQAABih8BFQh9BFixAAQivAAh9hFg");
	this.shape_27.setTransform(-22.9,-41.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#E0E0E0").s().p("AksCnQh9hFAAhiQAAhhB9hFQB9hGCvAAQCxAAB9BGQB8BFAABhQAABih8BFQh9BGixAAQivAAh9hGg");
	this.shape_28.setTransform(-22.9,-44);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#E0E0E0").s().p("AksCnQh9hFAAhiQAAhhB9hFQB9hFCvAAQCxAAB9BFQB8BFAABhQAABih8BFQh9BFixAAQivAAh9hFg");
	this.shape_29.setTransform(-22.9,-38.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#E0E0E0").s().p("AhDiHQA4AAAnAoQAoAoAAA3QAAA5goAnQgmAog5AAg");
	this.shape_30.setTransform(42.1,-17.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#F7EFEB").s().p("AgiA3QgHgDgDgIIgSguQgCgIADgHQADgIAIgDIBFgbQAIgCAHADQAIAEADAHIARAuQADAIgDAIQgEAHgHADIhGAbIgGABQgEAAgFgCg");
	this.shape_31.setTransform(74.7,80.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#616161").s().p("AgRAAIAfgKIADAKIgdALg");
	this.shape_32.setTransform(71.1,70.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgeALg");
	this.shape_33.setTransform(68.9,65.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgeALg");
	this.shape_34.setTransform(66.7,59.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgeALg");
	this.shape_35.setTransform(64.5,53.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#616161").s().p("AgQAAIAdgKIAEAKIgdALg");
	this.shape_36.setTransform(62.3,47.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_37.setTransform(60.1,41.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_38.setTransform(57.9,36);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_39.setTransform(55.7,30.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#616161").s().p("AgQAAIAdgKIAEAKIgdALg");
	this.shape_40.setTransform(53.5,24.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#616161").s().p("AgQABIAegLIADAKIgdALg");
	this.shape_41.setTransform(51.3,18.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#616161").s().p("AgQABIAegLIADAKIgdALg");
	this.shape_42.setTransform(49.1,12.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#616161").s().p("AgQABIAegLIADAKIgdALg");
	this.shape_43.setTransform(46.9,6.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#757575").s().p("AjDnZIAfgLIFoO+IgfALg");
	this.shape_44.setTransform(56.6,32.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#BDBDBD").s().p("AgRgDQAKgNAIgHIARAkIgJALg");
	this.shape_45.setTransform(68.9,83.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#20CA9A").s().p("AhCCRQg3gbgVg5QgXg9Acg6QAcg7A+gUQA2gTA3AYQA2AYAYA1QANAeAAAfQABAfgNAdQgDAKgLABQgKACgHgIQgIgJAEgKQASgqgQgqQgRgugtgTQgtgUgsATQgrARgTAtQgSArARArQARApAnAUQALAFAAALQAAALgJAGQgEADgFAAQgEAAgFgCg");
	this.shape_46.setTransform(79.3,91.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#E0E0E0").s().p("AgbBgQgogoAAg4QAAg3AogoQAngoA4AAIAAEPQg4AAgngog");
	this.shape_47.setTransform(-87.8,-17.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#E0E0E0").s().p("AmaCEQiripAAjxIAAgXQAFDnCmClQCqCqDwAAQDxAACqiqQCmilAFjnIAAAXQAADxirCpQiqCqjxABQjwgBiqiqg");
	this.shape_48.setTransform(-22.8,86.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#F2F2F2").s().p("AmaNvQiriqAAjxIAAunQAAjxCriqQCqirDwAAQDxAACqCrQCrCqAADxIAAOnQAADxirCqQiqCrjxAAQjwAAiqirg");
	this.shape_49.setTransform(-22.8,11.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.body, new cjs.Rectangle(-94.6,-116.3,189.2,232.6), null);


(lib.arm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F7EFEB").s().p("AggA4QgHgDgEgIIgTguQgDgHADgHQADgIAIgDIBFgdQAIgDAHADQAIADADAIIATAuQADAHgDAHQgDAIgIADIhFAdIgHACIgIgCg");
	this.shape.setTransform(-10.1,-34.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_1.setTransform(-6.3,-25.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_2.setTransform(-3.9,-19.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_3.setTransform(-1.5,-13.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#616161").s().p("AgQABIAdgMIAEALIgdALg");
	this.shape_4.setTransform(0.9,-7.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#616161").s().p("AgQABIAdgMIAEALIgdAMg");
	this.shape_5.setTransform(3.3,-2.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#616161").s().p("AgQABIAdgMIAEALIgdAMg");
	this.shape_6.setTransform(5.6,3.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#616161").s().p("AgQACIAdgNIAEALIgdAMg");
	this.shape_7.setTransform(8,9.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_8.setTransform(10.4,15.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_9.setTransform(12.8,20.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_10.setTransform(15.2,26.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_11.setTransform(17.5,32.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#616161").s().p("AgQABIAdgLIAEAKIgdALg");
	this.shape_12.setTransform(19.9,38.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#757575").s().p("AjSnSIAegNIGHOyIgeANg");
	this.shape_13.setTransform(9.5,12.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BDBDBD").s().p("AgMASIAAgmIANADIANAlIgEABQgKAAgMgDg");
	this.shape_14.setTransform(-16.2,-33.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#20CA9A").s().p("AgLBjQg8gYgZg8QgXg3AVg5QAEgKALgCQAKgCAHAIQAIAJgEAKQgQAqAQApQARArAsATQArAUArgRIAYAfQggAPggAAQgcAAgcgLg");
	this.shape_15.setTransform(-19.6,-42.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#20CA9A").s().p("Ag1BtQAtgRATgtQATgtgSgsQgRgqgqgTQgKgEgBgMQAAgLAIgGQAJgGAKAFQAcAMAUAXQAXAYAKAfQATA2gXA2QgYA3g0AYg");
	this.shape_16.setTransform(-5.6,-46.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.arm, new cjs.Rectangle(-30.5,-60.7,61.1,121.5), null);


// stage content:
(lib.animate = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text
	this.instance = new lib.text();
	this.instance.parent = this;
	this.instance.setTransform(318,44.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:44.5},0).wait(1).to({y:44.2},0).wait(1).to({y:43.8},0).wait(1).to({y:43.5},0).wait(1).to({y:43.2},0).wait(1).to({y:42.8},0).wait(1).to({y:42.5},0).wait(1).to({y:42.1},0).wait(1).to({y:41.8},0).wait(1).to({y:41.5},0).wait(1).to({y:41.1},0).wait(1).to({y:40.8},0).wait(1).to({y:40.4},0).wait(1).to({y:40.1},0).wait(1).to({y:39.8},0).wait(1).to({y:39.4},0).wait(1).to({y:39.1},0).wait(1).to({y:38.7},0).wait(1).to({y:38.4},0).wait(1).to({y:38.1},0).wait(1).to({y:37.7},0).wait(1).to({y:37.4},0).wait(1).to({y:37.1},0).wait(1).to({y:37.4},0).wait(1).to({y:37.7},0).wait(1).to({y:38},0).wait(1).to({y:38.4},0).wait(1).to({y:38.7},0).wait(1).to({y:39},0).wait(1).to({y:39.3},0).wait(1).to({y:39.7},0).wait(1).to({y:40},0).wait(1).to({y:40.3},0).wait(1).to({y:40.6},0).wait(1).to({y:41},0).wait(1).to({y:41.3},0).wait(1).to({y:41.6},0).wait(1).to({y:41.9},0).wait(1).to({y:42.3},0).wait(1).to({y:42.6},0).wait(1).to({y:42.9},0).wait(1).to({y:43.2},0).wait(1).to({y:43.6},0).wait(1).to({y:43.9},0).wait(1).to({y:44.2},0).wait(1).to({y:44.5},0).wait(1).to({y:44.9},0).wait(1));

	// e-8
	this.instance_1 = new lib.e8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(137.4,271.2,1,1,0,0,0,0.2,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:0.3,rotation:7.7,x:139.1,y:265.5,alpha:0.946},0).wait(1).to({rotation:15.3,x:142.7,y:260.8,alpha:0.891},0).wait(1).to({rotation:23,x:147.8,y:257.7,alpha:0.837},0).wait(1).to({rotation:30.6,x:153.3,y:255.8,alpha:0.783},0).wait(1).to({rotation:38.3,x:159.3,y:254.8,alpha:0.729},0).wait(1).to({rotation:46,x:165.3,y:254.4,alpha:0.674},0).wait(1).to({rotation:53.6,x:171.3,y:254.5,alpha:0.62},0).wait(1).to({rotation:61.3,x:177.2,y:254.9,alpha:0.566},0).wait(1).to({rotation:68.9,x:183.1,y:255.5,alpha:0.511},0).wait(1).to({rotation:76.6,x:189,y:256.3,alpha:0.457},0).wait(1).to({rotation:84.3,x:194.4,y:254.3,alpha:0.403},0).wait(1).to({rotation:91.9,x:199.9,y:252.7,alpha:0.349},0).wait(1).to({rotation:99.6,x:205.4,y:251.3,alpha:0.294},0).wait(1).to({rotation:107.2,x:211.1,y:250.5,alpha:0.24},0).wait(1).to({rotation:114.9,x:216.8,y:250.2,alpha:0.367},0).wait(1).to({rotation:122.6,x:222.5,y:250.6,alpha:0.493},0).wait(1).to({rotation:130.2,x:228.1,y:251.9,alpha:0.62},0).wait(1).to({rotation:137.9,x:233.3,y:254.2,alpha:0.747},0).wait(1).to({rotation:145.5,x:238,y:257.4,alpha:0.873},0).wait(1).to({rotation:153.2,x:242.1,y:261.5,alpha:1},0).wait(1).to({rotation:160.9,x:245.4,y:266.1,alpha:0.935},0).wait(1).to({rotation:168.5,x:248,y:271.2,alpha:0.87},0).wait(1).to({rotation:176.2,x:243.7,y:272.3,alpha:0.805},0).wait(1).to({rotation:183.8,x:239.4,y:273.4,alpha:0.74},0).wait(1).to({rotation:191.5,x:235,y:274.4,alpha:0.675},0).wait(1).to({rotation:199.1,x:230.6,y:275.3,alpha:0.61},0).wait(1).to({rotation:206.8,x:226.2,y:276,alpha:0.545},0).wait(1).to({rotation:214.5,x:221.7,y:276.8,alpha:0.48},0).wait(1).to({rotation:222.1,x:217.3,y:277.4,alpha:0.415},0).wait(1).to({rotation:229.8,x:212.9,y:277.9,alpha:0.35},0).wait(1).to({rotation:237.4,x:208.4,y:278.3,alpha:0.285},0).wait(1).to({rotation:245.1,x:203.9,y:278.7,alpha:0.22},0).wait(1).to({rotation:252.8,x:199.4,y:278.9,alpha:0.155},0).wait(1).to({rotation:260.4,x:195,y:279,alpha:0.09},0).wait(1).to({rotation:268.1,x:190.5,y:279.1,alpha:0.16},0).wait(1).to({rotation:275.7,x:186,y:279,alpha:0.23},0).wait(1).to({rotation:283.4,x:181.5,y:278.8,alpha:0.3},0).wait(1).to({rotation:291.1,x:177.1,y:278.5,alpha:0.37},0).wait(1).to({rotation:298.7,x:172.6,y:278.1,alpha:0.44},0).wait(1).to({rotation:306.4,x:168.2,y:277.6,alpha:0.51},0).wait(1).to({rotation:314,x:163.7,y:277.1,alpha:0.58},0).wait(1).to({rotation:321.7,x:159.3,y:276.3,alpha:0.65},0).wait(1).to({rotation:329.4,x:154.9,y:275.5,alpha:0.72},0).wait(1).to({rotation:337,x:150.5,y:274.6,alpha:0.79},0).wait(1).to({rotation:344.7,x:146.2,y:273.5,alpha:0.86},0).wait(1).to({rotation:352.3,x:141.8,y:272.4,alpha:0.93},0).wait(1).to({rotation:360,x:137.5,y:271.2,alpha:1},0).wait(1));

	// e-7
	this.instance_2 = new lib.e7();
	this.instance_2.parent = this;
	this.instance_2.setTransform(90.9,222,1,1,0,0,0,0,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({regY:0,rotation:-7.7,x:94.8,y:224,alpha:0.964},0).wait(1).to({rotation:-15.3,x:98.9,y:226.7,alpha:0.929},0).wait(1).to({rotation:-23,x:103.3,y:229.1,alpha:0.893},0).wait(1).to({rotation:-30.6,x:107.7,y:231.1,alpha:0.857},0).wait(1).to({rotation:-38.3,x:112.4,y:232.7,alpha:0.821},0).wait(1).to({rotation:-46,x:117.1,y:234,alpha:0.786},0).wait(1).to({rotation:-53.6,x:122,y:234.7,alpha:0.75},0).wait(1).to({rotation:-61.3,x:126.9,y:235,alpha:0.714},0).wait(1).to({rotation:-68.9,x:131.9,y:234.8,alpha:0.679},0).wait(1).to({rotation:-76.6,x:136.8,y:234.1,alpha:0.643},0).wait(1).to({rotation:-84.3,x:141.6,y:233,alpha:0.607},0).wait(1).to({rotation:-91.9,x:146.3,y:231.5,alpha:0.571},0).wait(1).to({rotation:-99.6,x:150.9,y:229.6,alpha:0.536},0).wait(1).to({rotation:-107.2,x:155.3,y:227.4,alpha:0.5},0).wait(1).to({rotation:-114.9,x:165.7,y:232.1,alpha:0.545},0).wait(1).to({rotation:-122.6,x:176.7,y:235,alpha:0.591},0).wait(1).to({rotation:-130.2,x:188.1,y:235.6,alpha:0.636},0).wait(1).to({rotation:-137.9,x:199.3,y:233.6,alpha:0.682},0).wait(1).to({rotation:-145.5,x:209.7,y:229.1,alpha:0.727},0).wait(1).to({rotation:-153.2,x:219,y:222.7,alpha:0.773},0).wait(1).to({rotation:-160.9,x:214.6,y:221,alpha:0.818},0).wait(1).to({rotation:-168.5,x:210.1,y:219.4,alpha:0.864},0).wait(1).to({rotation:-176.2,x:205.5,y:217.9,alpha:0.909},0).wait(1).to({rotation:-183.8,x:201,y:216.6,alpha:0.955},0).wait(1).to({rotation:-191.5,x:196.3,y:215.3,alpha:1},0).wait(1).to({rotation:-199.1,x:191.7,y:214.2},0).wait(1).to({rotation:-206.8,x:187,y:213.2},0).wait(1).to({rotation:-214.5,x:182.3,y:212.3},0).wait(1).to({rotation:-222.1,x:177.6,y:211.6},0).wait(1).to({rotation:-229.8,x:172.8,y:210.9},0).wait(1).to({rotation:-237.4,x:168,y:210.4},0).wait(1).to({rotation:-245.1,x:163.2,y:210.1},0).wait(1).to({rotation:-252.8,x:158.4,y:209.9},0).wait(1).to({rotation:-260.4,x:153.5,y:209.8},0).wait(1).to({rotation:-268.1,x:148.6},0).wait(1).to({rotation:-275.7,x:143.8,y:210},0).wait(1).to({rotation:-283.4,x:138.9,y:210.3},0).wait(1).to({rotation:-291.1,x:134,y:210.8},0).wait(1).to({rotation:-298.7,x:129.2,y:211.4},0).wait(1).to({rotation:-306.4,x:124.3,y:212.2},0).wait(1).to({rotation:-314,x:119.5,y:213.1},0).wait(1).to({rotation:-321.7,x:114.6,y:214.1},0).wait(1).to({rotation:-329.4,x:109.8,y:215.2},0).wait(1).to({rotation:-337,x:105,y:216.5},0).wait(1).to({rotation:-344.7,x:100.3,y:217.9},0).wait(1).to({rotation:-352.3,x:95.5,y:219.5},0).wait(1).to({rotation:-360,x:90.9,y:221.2},0).wait(1));

	// e-5
	this.instance_3 = new lib.e5();
	this.instance_3.parent = this;
	this.instance_3.setTransform(176.9,236);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({rotation:-7.7,x:184.3,y:232,alpha:0.965},0).wait(1).to({rotation:-15.3,x:192.2,y:228.9,alpha:0.93},0).wait(1).to({rotation:-23,x:200.3,y:226.8,alpha:0.896},0).wait(1).to({rotation:-30.6,x:208.7,y:225.8,alpha:0.861},0).wait(1).to({rotation:-38.3,x:217.2,alpha:0.826},0).wait(1).to({rotation:-46,x:225.5,y:226.8,alpha:0.791},0).wait(1).to({rotation:-53.6,x:233.8,y:228.7,alpha:0.757},0).wait(1).to({rotation:-61.3,x:241.8,y:231.3,alpha:0.722},0).wait(1).to({rotation:-68.9,x:247.1,y:228.5,alpha:0.687},0).wait(1).to({rotation:-76.6,x:252.6,y:226.1,alpha:0.652},0).wait(1).to({rotation:-84.3,x:258.3,y:224.1,alpha:0.617},0).wait(1).to({rotation:-91.9,x:264.2,y:222.6,alpha:0.583},0).wait(1).to({rotation:-99.6,x:270.1,y:221.6,alpha:0.548},0).wait(1).to({rotation:-107.2,x:276.1,y:221.2,alpha:0.513},0).wait(1).to({rotation:-114.9,x:282.1,y:221.3,alpha:0.478},0).wait(1).to({rotation:-122.6,x:288.1,y:222,alpha:0.443},0).wait(1).to({rotation:-130.2,x:293.9,y:223.2,alpha:0.409},0).wait(1).to({rotation:-137.9,x:299.7,y:224.9,alpha:0.374},0).wait(1).to({rotation:-145.5,x:305.3,y:227.1,alpha:0.339},0).wait(1).to({rotation:-153.2,x:310.7,y:229.7,alpha:0.304},0).wait(1).to({rotation:-160.9,x:316,y:232.7,alpha:0.27},0).wait(1).to({rotation:-168.5,x:321,y:236,alpha:0.235},0).wait(1).to({rotation:-176.2,x:315.4,y:237.7,alpha:0.2},0).wait(1).to({rotation:-183.8,x:309.7,y:239.2,alpha:0.233},0).wait(1).to({rotation:-191.5,x:304,y:240.6,alpha:0.267},0).wait(1).to({rotation:-199.1,x:298.3,y:241.9,alpha:0.3},0).wait(1).to({rotation:-206.8,x:292.6,y:243.1,alpha:0.333},0).wait(1).to({rotation:-214.5,x:286.8,y:244.2,alpha:0.367},0).wait(1).to({rotation:-222.1,x:281,y:245.1,alpha:0.4},0).wait(1).to({rotation:-229.8,x:275.2,y:245.8,alpha:0.433},0).wait(1).to({rotation:-237.4,x:269.4,y:246.5,alpha:0.467},0).wait(1).to({rotation:-245.1,x:263.6,y:246.9,alpha:0.5},0).wait(1).to({rotation:-252.8,x:257.7,y:247.3,alpha:0.533},0).wait(1).to({rotation:-260.4,x:251.8,y:247.5,alpha:0.567},0).wait(1).to({rotation:-268.1,x:246,alpha:0.6},0).wait(1).to({rotation:-275.7,x:240.1,y:247.4,alpha:0.633},0).wait(1).to({rotation:-283.4,x:234.3,y:247.1,alpha:0.667},0).wait(1).to({rotation:-291.1,x:228.4,y:246.7,alpha:0.7},0).wait(1).to({rotation:-298.7,x:222.6,y:246.1,alpha:0.733},0).wait(1).to({rotation:-306.4,x:216.8,y:245.4,alpha:0.767},0).wait(1).to({rotation:-314,x:211,y:244.5,alpha:0.8},0).wait(1).to({rotation:-321.7,x:205.2,y:243.4,alpha:0.833},0).wait(1).to({rotation:-329.4,x:199.5,y:242.3,alpha:0.867},0).wait(1).to({rotation:-337,x:193.8,y:240.9,alpha:0.9},0).wait(1).to({rotation:-344.7,x:188.1,y:239.4,alpha:0.933},0).wait(1).to({rotation:-352.3,x:182.5,y:237.8,alpha:0.967},0).wait(1).to({rotation:-360,x:176.9,y:236,alpha:1},0).wait(1));

	// e-4
	this.instance_4 = new lib.e4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(106.7,174.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1).to({rotation:7.7,x:111.9,y:172.3},0).wait(1).to({rotation:15.3,x:117.4,y:170.5},0).wait(1).to({rotation:23,x:122.9,y:169.3},0).wait(1).to({rotation:30.6,x:128.6,y:168.8},0).wait(1).to({rotation:38.3,x:134.4,y:169.2},0).wait(1).to({rotation:46,x:139.9,y:170.5},0).wait(1).to({rotation:53.6,x:145.2,y:172.6},0).wait(1).to({rotation:61.3,x:150.2,y:175.4},0).wait(1).to({rotation:68.9,x:154.8,y:178.8},0).wait(1).to({rotation:76.6,x:159.1,y:182.7},0).wait(1).to({rotation:84.3,x:163,y:186.9},0).wait(1).to({rotation:91.9,x:166.5,y:191.4},0).wait(1).to({rotation:99.6,x:171.2,y:186},0).wait(1).to({rotation:107.2,x:176.3,y:181},0).wait(1).to({rotation:114.9,x:181.7,y:176.4},0).wait(1).to({rotation:122.6,x:187.5,y:172.4},0).wait(1).to({rotation:130.2,x:193.8,y:169},0).wait(1).to({rotation:137.9,x:200.5,y:166.5},0).wait(1).to({rotation:145.5,x:207.4,y:165},0).wait(1).to({rotation:153.2,x:214.5,y:164.5},0).wait(1).to({rotation:160.9,x:221.6,y:165},0).wait(1).to({rotation:168.5,x:228.5,y:166.4},0).wait(1).to({rotation:176.2,x:235.3,y:168.5},0).wait(1).to({rotation:183.8,x:241.8,y:171.4},0).wait(1).to({rotation:191.5,x:248.1,y:174.7},0).wait(1).to({rotation:199.1,x:242,y:177.4},0).wait(1).to({rotation:206.8,x:235.8,y:179.9},0).wait(1).to({rotation:214.5,x:229.5,y:182.2},0).wait(1).to({rotation:222.1,x:223.2,y:184.2},0).wait(1).to({rotation:229.8,x:216.8,y:186},0).wait(1).to({rotation:237.4,x:210.3,y:187.6},0).wait(1).to({rotation:245.1,x:203.8,y:188.9},0).wait(1).to({rotation:252.8,x:197.2,y:189.9},0).wait(1).to({rotation:260.4,x:190.6,y:190.7},0).wait(1).to({rotation:268.1,x:184,y:191.2},0).wait(1).to({rotation:275.7,x:177.3,y:191.4},0).wait(1).to({rotation:283.4,x:170.6,y:191.3},0).wait(1).to({rotation:291.1,x:164,y:190.9},0).wait(1).to({rotation:298.7,x:157.4,y:190.2},0).wait(1).to({rotation:306.4,x:150.8,y:189.2},0).wait(1).to({rotation:314,x:144.3,y:187.9},0).wait(1).to({rotation:321.7,x:137.8,y:186.3},0).wait(1).to({rotation:329.4,x:131.4,y:184.5},0).wait(1).to({rotation:337,x:125.1,y:182.4},0).wait(1).to({rotation:344.7,x:118.9,y:180},0).wait(1).to({rotation:352.3,x:112.7,y:177.5},0).wait(1).to({rotation:360,x:106.7,y:174.7},0).wait(1));

	// e-3
	this.instance_5 = new lib.e3();
	this.instance_5.parent = this;
	this.instance_5.setTransform(148.4,165.1,1,1,0,0,0,-0.2,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({rotation:-7.7,x:151.6,y:163.2},0).wait(1).to({rotation:-15.3,x:155,y:161.7},0).wait(1).to({rotation:-23,x:158.6,y:160.8},0).wait(1).to({rotation:-30.6,x:162.4,y:160.5},0).wait(1).to({rotation:-38.3,x:166.1,y:160.8},0).wait(1).to({rotation:-46,x:169.7,y:162},0).wait(1).to({rotation:-53.6,x:173.1,y:163.5},0).wait(1).to({rotation:-61.3,x:176.2,y:165.6},0).wait(1).to({rotation:-68.9,x:179.1,y:168},0).wait(1).to({rotation:-76.6,x:181.8,y:170.6},0).wait(1).to({rotation:-84.3,x:184.1,y:168.8},0).wait(1).to({rotation:-91.9,x:186.5,y:167.2},0).wait(1).to({rotation:-99.6,x:189.1,y:165.7},0).wait(1).to({rotation:-107.2,x:191.7,y:164.5},0).wait(1).to({rotation:-114.9,x:194.5,y:163.5},0).wait(1).to({rotation:-122.6,x:197.3,y:162.7},0).wait(1).to({rotation:-130.2,x:200.2,y:162.4},0).wait(1).to({rotation:-137.9,x:203.1,y:162.3},0).wait(1).to({rotation:-145.5,x:206,y:162.6},0).wait(1).to({rotation:-153.2,x:208.9,y:163.2},0).wait(1).to({rotation:-160.9,x:211.7,y:164},0).wait(1).to({rotation:-168.5,x:214.4,y:165.1},0).wait(1).to({rotation:-176.2,x:211.9,y:163.9},0).wait(1).to({rotation:-183.8,x:209.4,y:162.8},0).wait(1).to({rotation:-191.5,x:206.8,y:161.8},0).wait(1).to({rotation:-199.1,x:204.3,y:160.8},0).wait(1).to({rotation:-206.8,x:201.7,y:160},0).wait(1).to({rotation:-214.5,x:199,y:159.2},0).wait(1).to({rotation:-222.1,x:196.3,y:158.5},0).wait(1).to({rotation:-229.8,x:193.7,y:158},0).wait(1).to({rotation:-237.4,x:191,y:157.6},0).wait(1).to({rotation:-245.1,x:188.3,y:157.2},0).wait(1).to({rotation:-252.8,x:185.5,y:157},0).wait(1).to({rotation:-260.4,x:182.8,y:156.8},0).wait(1).to({rotation:-268.1,x:180,y:156.9},0).wait(1).to({rotation:-275.7,x:177.3,y:157},0).wait(1).to({rotation:-283.4,x:174.5,y:157.2},0).wait(1).to({rotation:-291.1,x:171.8,y:157.5},0).wait(1).to({rotation:-298.7,x:169.1,y:158},0).wait(1).to({rotation:-306.4,x:166.4,y:158.6},0).wait(1).to({rotation:-314,x:163.7,y:159.2},0).wait(1).to({rotation:-321.7,x:161.1,y:160},0).wait(1).to({rotation:-329.4,x:158.5,y:160.8},0).wait(1).to({rotation:-337,x:155.9,y:161.7},0).wait(1).to({rotation:-344.7,x:153.4,y:162.8},0).wait(1).to({rotation:-352.3,x:150.8,y:163.9},0).wait(1).to({rotation:-360,x:148.4,y:165.1},0).wait(1));

	// e-2
	this.instance_6 = new lib.e2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(202.1,156.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1).to({x:203.8,y:158.7},0).wait(1).to({x:205.7,y:160.7},0).wait(1).to({x:207.8,y:162.5},0).wait(1).to({x:210,y:164.1},0).wait(1).to({x:212.4,y:165.5},0).wait(1).to({x:215,y:166.5},0).wait(1).to({x:217.6,y:167.1},0).wait(1).to({x:220.4,y:167.2},0).wait(1).to({x:223.1,y:166.8},0).wait(1).to({x:225.8,y:166},0).wait(1).to({x:228.3,y:164.9},0).wait(1).to({x:230.7,y:163.5},0).wait(1).to({x:232.9,y:162},0).wait(1).to({x:235.1,y:160.2},0).wait(1).to({x:240.4,y:164.1},0).wait(1).to({x:246.3,y:166.9},0).wait(1).to({x:252.8,y:167.8},0).wait(1).to({x:259.1,y:165.9},0).wait(1).to({x:264.2,y:161.8},0).wait(1).to({x:268.1,y:156.6},0).wait(1).to({x:265.8,y:155.4},0).wait(1).to({x:263.5,y:154.3},0).wait(1).to({x:261.2,y:153.3},0).wait(1).to({x:258.8,y:152.3},0).wait(1).to({x:256.4,y:151.4},0).wait(1).to({x:254,y:150.7},0).wait(1).to({x:251.5,y:150},0).wait(1).to({x:249,y:149.3},0).wait(1).to({x:246.5,y:148.8},0).wait(1).to({x:244,y:148.4},0).wait(1).to({x:241.5,y:148.1},0).wait(1).to({x:238.9,y:147.9},0).wait(1).to({x:236.4,y:147.8},0).wait(1).to({x:233.8},0).wait(1).to({x:231.2,y:147.9},0).wait(1).to({x:228.7,y:148.1},0).wait(1).to({x:226.2,y:148.4},0).wait(1).to({x:223.6,y:148.8},0).wait(1).to({x:221.1,y:149.3},0).wait(1).to({x:218.6,y:149.9},0).wait(1).to({x:216.2,y:150.6},0).wait(1).to({x:213.8,y:151.4},0).wait(1).to({x:211.3,y:152.3},0).wait(1).to({x:209,y:153.2},0).wait(1).to({x:206.6,y:154.3},0).wait(1).to({x:204.3,y:155.4},0).wait(1).to({x:202.1,y:156.6},0).wait(1));

	// element-1
	this.instance_7 = new lib.element1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(163.1,147.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1).to({x:165.3,y:149},0).wait(1).to({x:167.7,y:150.8},0).wait(1).to({x:170.1,y:152.4},0).wait(1).to({x:172.6,y:153.9},0).wait(1).to({x:175.2,y:155.3},0).wait(1).to({x:177.8,y:156.5},0).wait(1).to({x:180.5,y:157.6},0).wait(1).to({x:183.2,y:158.6},0).wait(1).to({x:186,y:159.4},0).wait(1).to({x:188.8,y:160},0).wait(1).to({x:191.7,y:160.4},0).wait(1).to({x:194.6,y:160.6},0).wait(1).to({x:197.5},0).wait(1).to({x:200.4,y:160.4},0).wait(1).to({x:203.3,y:160},0).wait(1).to({x:206.1,y:159.4},0).wait(1).to({x:208.9,y:158.6},0).wait(1).to({x:211.7,y:157.7},0).wait(1).to({x:214.4,y:156.5},0).wait(1).to({x:217,y:155.3},0).wait(1).to({x:219.5,y:153.9},0).wait(1).to({x:222,y:152.4},0).wait(1).to({x:224.4,y:150.8},0).wait(1).to({x:226.8,y:149},0).wait(1).to({x:229.1,y:147.3},0).wait(1).to({x:226.2,y:146.3},0).wait(1).to({x:223.3,y:145.4},0).wait(1).to({x:220.3,y:144.6},0).wait(1).to({x:217.3,y:143.9},0).wait(1).to({x:214.3,y:143.3},0).wait(1).to({x:211.3,y:142.8},0).wait(1).to({x:208.3,y:142.4},0).wait(1).to({x:205.3,y:142.1},0).wait(1).to({x:202.2,y:141.9},0).wait(1).to({x:199.2,y:141.8},0).wait(1).to({x:196.1},0).wait(1).to({x:193},0).wait(1).to({x:190,y:142},0).wait(1).to({x:186.9,y:142.3},0).wait(1).to({x:183.9,y:142.6},0).wait(1).to({x:180.9,y:143},0).wait(1).to({x:177.9,y:143.5},0).wait(1).to({x:174.9,y:144.1},0).wait(1).to({x:171.9,y:144.8},0).wait(1).to({x:168.9,y:145.5},0).wait(1).to({x:166,y:146.4},0).wait(1).to({x:163.1,y:147.3},0).wait(1));

	// scan-4
	this.instance_8 = new lib.scan3();
	this.instance_8.parent = this;
	this.instance_8.setTransform(234.3,196.5,1,1,-60);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(24).to({_off:false},0).wait(1).to({rotation:-57.4,x:230.6},0).wait(1).to({rotation:-54.8,x:226.9,y:196.6},0).wait(1).to({rotation:-52.2,x:223.2},0).wait(1).to({rotation:-49.6,x:219.5,y:196.7},0).wait(1).to({rotation:-47,x:215.8},0).wait(1).to({rotation:-44.3,x:212.2,y:196.8},0).wait(1).to({rotation:-41.7,x:208.5},0).wait(1).to({rotation:-39.1,x:204.8,y:196.9},0).wait(1).to({rotation:-36.5,x:201.1},0).wait(1).to({rotation:-33.9,x:197.4,y:197},0).wait(1).to({rotation:-31.3,x:193.8},0).wait(1).to({rotation:-28.7,x:190.1,y:197.1},0).wait(1).to({rotation:-26.1,x:186.4},0).wait(1).to({rotation:-23.5,x:182.7,y:197.2},0).wait(1).to({rotation:-20.9,x:179},0).wait(1).to({rotation:-18.3,x:175.4,y:197.3},0).wait(1).to({rotation:-15.7,x:171.7},0).wait(1).to({rotation:-13,x:168,y:197.4},0).wait(1).to({rotation:-10.4,x:164.3},0).wait(1).to({rotation:-7.8,x:160.6,y:197.5},0).wait(1).to({rotation:-5.2,x:157},0).wait(1).to({rotation:-2.6,x:153.3,y:197.6},0).wait(1).to({rotation:0,x:149.6},0).wait(1));

	// scan-3
	this.instance_9 = new lib.scan3();
	this.instance_9.parent = this;
	this.instance_9.setTransform(149.6,197.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1).to({rotation:-2.6,x:153.3},0).wait(1).to({rotation:-5.2,x:157,y:197.5},0).wait(1).to({rotation:-7.8,x:160.6},0).wait(1).to({rotation:-10.4,x:164.3,y:197.4},0).wait(1).to({rotation:-13,x:168},0).wait(1).to({rotation:-15.7,x:171.7,y:197.3},0).wait(1).to({rotation:-18.3,x:175.4},0).wait(1).to({rotation:-20.9,x:179,y:197.2},0).wait(1).to({rotation:-23.5,x:182.7},0).wait(1).to({rotation:-26.1,x:186.4,y:197.1},0).wait(1).to({rotation:-28.7,x:190.1},0).wait(1).to({rotation:-31.3,x:193.8,y:197},0).wait(1).to({rotation:-33.9,x:197.4},0).wait(1).to({rotation:-36.5,x:201.1,y:196.9},0).wait(1).to({rotation:-39.1,x:204.8},0).wait(1).to({rotation:-41.7,x:208.5,y:196.8},0).wait(1).to({rotation:-44.3,x:212.2},0).wait(1).to({rotation:-47,x:215.8,y:196.7},0).wait(1).to({rotation:-49.6,x:219.5},0).wait(1).to({rotation:-52.2,x:223.2,y:196.6},0).wait(1).to({rotation:-54.8,x:226.9},0).wait(1).to({rotation:-57.4,x:230.6,y:196.5},0).wait(1).to({rotation:-60,x:234.3},0).to({_off:true},1).wait(24));

	// wave
	this.instance_10 = new lib.wave();
	this.instance_10.parent = this;
	this.instance_10.setTransform(199.8,31);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1).to({x:199.7,y:30.8,alpha:0.965},0).wait(1).to({y:30.6,alpha:0.93},0).wait(1).to({y:30.4,alpha:0.896},0).wait(1).to({x:199.6,y:30.2,alpha:0.861},0).wait(1).to({y:30,alpha:0.826},0).wait(1).to({y:29.8,alpha:0.791},0).wait(1).to({y:29.6,alpha:0.757},0).wait(1).to({x:199.5,y:29.4,alpha:0.722},0).wait(1).to({y:29.2,alpha:0.687},0).wait(1).to({y:29,alpha:0.652},0).wait(1).to({x:199.4,y:28.8,alpha:0.617},0).wait(1).to({y:28.6,alpha:0.583},0).wait(1).to({y:28.4,alpha:0.548},0).wait(1).to({y:28.2,alpha:0.513},0).wait(1).to({x:199.3,y:28,alpha:0.478},0).wait(1).to({y:27.8,alpha:0.443},0).wait(1).to({y:27.6,alpha:0.409},0).wait(1).to({x:199.2,y:27.4,alpha:0.374},0).wait(1).to({y:27.2,alpha:0.339},0).wait(1).to({y:27,alpha:0.304},0).wait(1).to({y:26.8,alpha:0.27},0).wait(1).to({x:199.1,y:26.6,alpha:0.235},0).wait(1).to({y:26.4,alpha:0.2},0).wait(1).to({y:26.5,alpha:0.233},0).wait(1).to({x:199.2,y:26.7,alpha:0.267},0).wait(1).to({y:26.9,alpha:0.3},0).wait(1).to({y:27.1,alpha:0.333},0).wait(1).to({y:27.3,alpha:0.367},0).wait(1).to({x:199.3,y:27.5,alpha:0.4},0).wait(1).to({y:27.7,alpha:0.433},0).wait(1).to({y:27.9,alpha:0.467},0).wait(1).to({y:28.1,alpha:0.5},0).wait(1).to({x:199.4,y:28.3,alpha:0.533},0).wait(1).to({y:28.5,alpha:0.567},0).wait(1).to({y:28.7,alpha:0.6},0).wait(1).to({x:199.5,y:28.9,alpha:0.633},0).wait(1).to({y:29.1,alpha:0.667},0).wait(1).to({y:29.3,alpha:0.7},0).wait(1).to({y:29.5,alpha:0.733},0).wait(1).to({x:199.6,y:29.6,alpha:0.767},0).wait(1).to({y:29.8,alpha:0.8},0).wait(1).to({y:30,alpha:0.833},0).wait(1).to({y:30.2,alpha:0.867},0).wait(1).to({x:199.7,y:30.4,alpha:0.9},0).wait(1).to({y:30.6,alpha:0.933},0).wait(1).to({y:30.8,alpha:0.967},0).wait(1).to({x:199.8,y:31,alpha:1},0).wait(1));

	// body
	this.instance_11 = new lib.body();
	this.instance_11.parent = this;
	this.instance_11.setTransform(222,158.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(48));

	// arm
	this.instance_12 = new lib.arm();
	this.instance_12.parent = this;
	this.instance_12.setTransform(141.5,142,1,1,0,0,0,31.1,60.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(1).to({regX:0,regY:0,rotation:-2,x:108.3,y:82.3},0).wait(1).to({rotation:-4,x:106.2,y:83.5},0).wait(1).to({rotation:-6,x:104.2,y:84.8},0).wait(1).to({rotation:-8,x:102.3,y:86.1},0).wait(1).to({rotation:-10,x:100.3,y:87.5},0).wait(1).to({rotation:-12,x:98.5,y:89},0).wait(1).to({rotation:-14,x:96.6,y:90.5},0).wait(1).to({rotation:-16,x:94.9,y:92.1},0).wait(1).to({rotation:-18,x:93.2,y:93.8},0).wait(1).to({rotation:-20,x:91.5,y:95.5},0).wait(1).to({rotation:-22,x:89.9,y:97.2},0).wait(1).to({rotation:-20.1,x:91.4,y:95.6},0).wait(1).to({rotation:-18.3,x:92.9,y:94},0).wait(1).to({rotation:-16.5,x:94.4,y:92.5},0).wait(1).to({rotation:-14.6,x:96,y:91},0).wait(1).to({rotation:-12.8,x:97.7,y:89.6},0).wait(1).to({rotation:-11,x:99.4,y:88.2},0).wait(1).to({rotation:-9.1,x:101.1,y:86.9},0).wait(1).to({rotation:-7.3,x:102.9,y:85.7},0).wait(1).to({rotation:-5.5,x:104.7,y:84.5},0).wait(1).to({rotation:-3.7,x:106.6,y:83.3},0).wait(1).to({rotation:-1.8,x:108.5,y:82.2},0).wait(1).to({rotation:0,x:110.4,y:81.2},0).wait(1).to({rotation:-1.8,x:108.5,y:82.2},0).wait(1).to({rotation:-3.6,x:106.6,y:83.3},0).wait(1).to({rotation:-5.5,x:104.8,y:84.4},0).wait(1).to({rotation:-7.3,x:102.9,y:85.6},0).wait(1).to({rotation:-9.1,x:101.2,y:86.9},0).wait(1).to({rotation:-10.9,x:99.4,y:88.2},0).wait(1).to({rotation:-12.7,x:97.8,y:89.6},0).wait(1).to({rotation:-14.6,x:96.1,y:91},0).wait(1).to({rotation:-16.4,x:94.5,y:92.4},0).wait(1).to({rotation:-18.2,x:93,y:94},0).wait(1).to({rotation:-20,x:91.5,y:95.5},0).wait(1).to({rotation:-21.8,x:90,y:97.1},0).wait(1).to({rotation:-20,x:91.5,y:95.5},0).wait(1).to({rotation:-18.2,x:93,y:94},0).wait(1).to({rotation:-16.4,x:94.5,y:92.4},0).wait(1).to({rotation:-14.6,x:96.1,y:91},0).wait(1).to({rotation:-12.7,x:97.8,y:89.6},0).wait(1).to({rotation:-10.9,x:99.4,y:88.2},0).wait(1).to({rotation:-9.1,x:101.2,y:86.9},0).wait(1).to({rotation:-7.3,x:102.9,y:85.6},0).wait(1).to({rotation:-5.5,x:104.8,y:84.4},0).wait(1).to({rotation:-3.6,x:106.6,y:83.3},0).wait(1).to({rotation:-1.8,x:108.5,y:82.2},0).wait(1).to({rotation:0,x:110.4,y:81.2},0).wait(1));

	// shadow
	this.instance_13 = new lib.shadow();
	this.instance_13.parent = this;
	this.instance_13.setTransform(199,294);
	this.instance_13.alpha = 0.191;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(1).to({alpha:0.19},0).wait(47));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(279.9,180.5,311.3,279.2);
// library properties:
lib.properties = {
	id: '5592B3BFBCCD480A9EBD033286C5C55D',
	width: 400,
	height: 320,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5592B3BFBCCD480A9EBD033286C5C55D'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createScanJs = createjs||{}, AdobeAn = AdobeAn||{});
var createScanJs, AdobeAn;