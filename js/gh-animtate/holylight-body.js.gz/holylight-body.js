(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0E0E0").s().p("AjsAnQhigQAAgXQAAgWBigQQBigRCKAAQCKAABkARQBhAQAAAWQAAAXhhAQQhjARiLAAQiKAAhigRg");
	this.shape.setTransform(33.6,5.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,67.1,11.2), null);


(lib.star2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLAMIhJgMIBJgLIALhJIAMBJIBJALIhJAMIgMBJg");
	this.shape.setTransform(8.5,8.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.star2, new cjs.Rectangle(0,0,17,17), null);


(lib.star1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgHAJIg2gJIA2gHIAHg2IAJA2IA1AHIg1AJIgJA1g");
	this.shape.setTransform(6.2,6.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.star1, new cjs.Rectangle(0,0,12.4,12.4), null);


(lib.righthand = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F7EFEB").s().p("AgHBAQgIgCgEgHIgmhAQgEgHACgIQACgIAHgEIArgZQAHgEAHACQAIACAFAHIAmBAQAEAHgCAIQgCAIgHAEIgsAZQgEADgFAAIgFgBg");
	this.shape.setTransform(89.1,22);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#616161").s().p("AgMgKIAJgGIAQAbIgKAGg");
	this.shape_1.setTransform(80.4,27.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#616161").s().p("AgMgKIAKgGIAPAbIgJAGg");
	this.shape_2.setTransform(75,30.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#616161").s().p("AgMgLIAJgFIAQAbIgJAGg");
	this.shape_3.setTransform(69.6,33.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#616161").s().p("AgMgKIAJgGIAQAcIgKAFg");
	this.shape_4.setTransform(64.3,36.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#616161").s().p("AgMgLIAJgFIAQAcIgJAFg");
	this.shape_5.setTransform(58.9,39.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#616161").s().p("AgMgKIAJgGIAQAcIgJAFg");
	this.shape_6.setTransform(53.5,42.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#616161").s().p("AgMgKIAKgGIAPAbIgKAGg");
	this.shape_7.setTransform(48.2,46.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#616161").s().p("AgMgKIAJgGIAQAbIgJAGg");
	this.shape_8.setTransform(42.8,49.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#616161").s().p("AgMgKIAJgGIAQAbIgJAGg");
	this.shape_9.setTransform(37.4,52.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#616161").s().p("AgMgKIAKgGIAPAbIgKAGg");
	this.shape_10.setTransform(32.1,55.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#616161").s().p("AgMgKIAJgGIAQAbIgJAGg");
	this.shape_11.setTransform(26.7,58.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#616161").s().p("AgMgKIAKgGIAPAbIgJAGg");
	this.shape_12.setTransform(21.4,61.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#757575").s().p("AnBD2INyoHIARAcItyIHg");
	this.shape_13.setTransform(45,48);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BDBDBD").s().p("AgWAEIAggWIANAHIgXAeQgLgFgLgKg");
	this.shape_14.setTransform(93.3,27);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#20CA9A").s().p("AglCTQhAgRgeg6QgcgzAOg5QAPg6AwggQA3gmBAAQQAKACADAKQAEAKgHAIQgIAJgLgDQgsgKgnAXQgqAZgLAwQgMAuAaApQAZAoAvALQAuALAngZQAmgXAMgrQADgLAMgCQAKgCAIAIQAHAHgDAKQgRA7g0AfQglAWgoAAQgUAAgVgHg");
	this.shape_15.setTransform(100.1,15.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.righthand, new cjs.Rectangle(0,0,115.2,75.4), null);


(lib.lefthand = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F7EFEB").s().p("AgGA+IgsgZQgHgEgCgIQgCgIAEgHIAmhAQAEgHAIgDQAHgCAHAEIAsAaQAHAEACAIQACAIgEAHIgmBAQgEAHgIADIgFAAQgFAAgEgDg");
	this.shape.setTransform(26,21.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#616161").s().p("AgMALIAQgbIAJAGIgPAbg");
	this.shape_1.setTransform(34.8,27);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#616161").s().p("AgMALIAQgbIAJAGIgQAbg");
	this.shape_2.setTransform(40.2,30.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#616161").s().p("AgMALIAPgbIAKAGIgQAbg");
	this.shape_3.setTransform(45.6,33.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#616161").s().p("AgMALIAPgbIAKAGIgQAbg");
	this.shape_4.setTransform(51,36.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#616161").s().p("AgMALIAPgbIAKAGIgPAbg");
	this.shape_5.setTransform(56.3,39.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#616161").s().p("AgMAMIAPgcIAKAFIgPAcg");
	this.shape_6.setTransform(61.7,42.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#616161").s().p("AgMAMIAQgcIAJAFIgQAcg");
	this.shape_7.setTransform(67.1,45.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#616161").s().p("AgMAMIAQgcIAJAFIgQAcg");
	this.shape_8.setTransform(72.5,49);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#616161").s().p("AgMALIAPgbIAKAGIgPAbg");
	this.shape_9.setTransform(77.8,52.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#616161").s().p("AgMALIAPgbIAKAGIgPAbg");
	this.shape_10.setTransform(83.2,55.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#616161").s().p("AgMALIAQgbIAJAGIgQAbg");
	this.shape_11.setTransform(88.6,58.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#616161").s().p("AgMALIAQgbIAJAGIgQAbg");
	this.shape_12.setTransform(94,61.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#757575").s().p("AnCjzIARgcIN0IDIgRAcg");
	this.shape_13.setTransform(70.3,47.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BDBDBD").s().p("AgWgLIANgHIAgAWQgLAKgLAFg");
	this.shape_14.setTransform(21.9,27);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#20CA9A").s().p("AhPCEQg0gegSg7QgCgKAHgIQAHgIAKACQAMACADALQANAsAlAWQAoAYAugLQAvgLAYgnQAagqgMguQgMgvgqgZQgngXgsAKQgLADgHgJQgHgIADgKQAEgKAKgDQAegHAeAGQAgAFAbASQAwAhAPA5QAOA5gbAzQgfA6g/ASQgWAGgUAAQgnAAglgVg");
	this.shape_15.setTransform(15,15.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.lefthand, new cjs.Rectangle(0,0,115.4,75), null);


(lib.eye = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#20CA9A").s().p("AgLAMQgEgFAAgHQAAgFAEgGQAFgEAGAAQAHAAAEAEQAFAGAAAFQAAAGgFAGQgEAEgHAAQgGAAgFgEg");
	this.shape.setTransform(1.6,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#20CA9A").s().p("AgKALQgFgEAAgHQAAgFAFgFQAFgFAFAAQAHAAAEAFQAFAFAAAFQAAAHgFAEQgEAFgHAAQgFAAgFgFg");
	this.shape_1.setTransform(7.8,10.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#20CA9A").s().p("AgKAMQgFgGAAgGQAAgFAFgGQAEgEAGAAQAHAAAEAEQAFAGAAAFQAAAGgFAGQgEAEgHAAQgGAAgEgEg");
	this.shape_2.setTransform(7.8,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#20CA9A").s().p("AgKALQgFgEAAgHQAAgGAFgFQAEgEAGAAQAHAAAEAEQAFAFAAAGQAAAGgFAFQgEAFgHAAQgFAAgFgFg");
	this.shape_3.setTransform(7.8,22.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#20CA9A").s().p("AgLALQgEgEAAgHQAAgGAEgFQAGgEAFAAQAHAAAFAEQAEAFAAAGQAAAHgEAEQgGAFgGAAQgFAAgGgFg");
	this.shape_4.setTransform(14,4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#20CA9A").s().p("AgLALQgEgEAAgHQAAgGAEgEQAGgFAFAAQAGAAAGAFQAEAEAAAGQAAAHgEAEQgGAFgGAAQgFAAgGgFg");
	this.shape_5.setTransform(14,10.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#20CA9A").s().p("AgLAMQgEgFAAgHQAAgFAEgGQAGgEAFAAQAHAAAFAEQAEAGAAAFQAAAHgEAFQgFAEgHAAQgFAAgGgEg");
	this.shape_6.setTransform(14,16.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#20CA9A").s().p("AgLALQgEgEAAgHQAAgGAEgFQAGgEAFAAQAHAAAFAEQAEAFAAAGQAAAHgEAEQgGAFgGAAQgFAAgGgFg");
	this.shape_7.setTransform(14,22.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#20CA9A").s().p("AgLALQgEgEAAgHQAAgGAEgEQAGgFAFAAQAGAAAGAFQAEAEAAAGQAAAHgEAEQgGAFgGAAQgFAAgGgFg");
	this.shape_8.setTransform(14,28.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#20CA9A").s().p("AgLALQgEgEAAgHQAAgGAEgEQAFgFAGAAQAHAAAEAFQAFAFAAAFQAAAHgFAEQgFAFgGAAQgGAAgFgFg");
	this.shape_9.setTransform(20.1,10.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#20CA9A").s().p("AgLAMQgEgFAAgHQAAgFAEgGQAFgEAGAAQAHAAAEAEQAFAGAAAFQAAAGgFAGQgEAEgHAAQgGAAgFgEg");
	this.shape_10.setTransform(20.1,16.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#20CA9A").s().p("AgLALQgEgEAAgHQAAgGAEgFQAFgEAGAAQAHAAAEAEQAFAFAAAGQAAAHgFAEQgEAFgHAAQgGAAgFgFg");
	this.shape_11.setTransform(20.1,22.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#20CA9A").s().p("AgKAMQgFgGAAgGQAAgFAFgGQAEgEAGAAQAHAAAEAEQAFAGAAAFQAAAGgFAGQgEAEgHAAQgGAAgEgEg");
	this.shape_12.setTransform(26.3,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(24));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,2.4,27.9,27.9);


(lib.body = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0E0E0").s().p("AmaCEQiripAAjxIAAgYQAFDoCmClQCqCqDwAAQDxAACqiqQCmilAFjoIAAAYQAADxirCpQiqCrjxAAQjwAAiqirg");
	this.shape.setTransform(71.8,202.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1BB482").s().p("AAAAwQgjgBgZgZQgZgZAAgjIABgJQADAhAYAVQAYAWAhAAQAhABAZgXQAYgVAEghIAAALQAAAjgaAYQgZAZgjAAIAAAAg");
	this.shape_1.setTransform(72.4,12.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#20CA9A").s().p("AgzASIAAgjIBnAAIAAAjg");
	this.shape_2.setTransform(67.2,166);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#20CA9A").s().p("AhEASIAAgjICJAAIAAAjg");
	this.shape_3.setTransform(65.5,159.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#20CA9A").s().p("AhVASIAAgjICrAAIAAAjg");
	this.shape_4.setTransform(63.8,153);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#20CA9A").s().p("AhzEBQgNAAgPgIQgPgJgGgMIh0jHQgGgMAAgRQAAgQAGgMIB0jIQAHgLAOgJQAPgIANAAIDmAAQAOAAAOAIQAPAJAHALIBzDIQAHAMAAAQQAAARgHAMIhzDHQgHAMgPAJQgOAIgOAAgAh1jLQgGADgCADIhsC8QgCADAAAGQAAAHACADIBsC8QACADAGADQAGAEADAAIDYAAQAEAAAGgEQAFgDACgDIBti8QACgDAAgHQAAgGgCgDIhti8QgCgDgFgDQgGgEgEAAIjYAAQgEAAgFAEg");
	this.shape_5.setTransform(72.4,150.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E0E0E0").s().p("AgzASIAAgjIBnAAIAAAjg");
	this.shape_6.setTransform(67.2,167);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E0E0E0").s().p("AhEASIAAgjICJAAIAAAjg");
	this.shape_7.setTransform(65.5,160.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E0E0E0").s().p("AhVASIAAgjICrAAIAAAjg");
	this.shape_8.setTransform(63.8,153.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E0E0E0").s().p("AhzEBQgNAAgPgIQgPgJgGgMIh0jHQgGgMAAgRQAAgQAGgLIB0jJQAHgLAOgJQAPgIANAAIDmAAQAOAAAOAIQAPAJAHALIBzDJQAHALAAAQQAAARgHAMIhzDHQgHAMgPAJQgOAIgOAAgAh1jLQgGADgCADIhsC8QgCADAAAGQAAAHACADIBsC8QACADAGADQAGAEADAAIDYAAQAEAAAGgEQAFgDACgDIBti8QACgDAAgHQAAgGgCgDIhti8QgCgDgFgDQgGgEgEABIjYAAQgDgBgGAEg");
	this.shape_9.setTransform(72.4,151.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#20CA9A").s().p("AAABWQgjAAgZgaQgagZABgjQAAgjAagZQAZgaAjABQAjAAAZAaQAaAZgBAjQAAAkgaAZQgZAYgjAAIAAAAg");
	this.shape_10.setTransform(72.4,8.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#757575").s().p("AgMBhIABjBIAYAAIgBDBg");
	this.shape_11.setTransform(72.4,21.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BDBDBD").s().p("AgfiHQAMAAAOADIAlD8QgfAQggAAg");
	this.shape_12.setTransform(133.2,98.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E0E0E0").s().p("AhhAQQgIAAgJgDQgGgHgEgLIgEgKQAEAJAJAGQAIAEAKAAIDCAAQAWAAAJgTIABAAQgFARgKALQgIADgJAAg");
	this.shape_13.setTransform(71.8,39.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhhBNQgNAAgLgIQgMgHgFgMIg6h6IAMgEIA4B5QAEAJAJAFQAJAGAJAAIDCAAQAXAAAJgUIA4h5IALAEIg4B6QgGAMgLAHQgMAIgOAAg");
	this.shape_14.setTransform(71.8,33.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#424242").s().p("AksCnQh9hFAAhiQAAhhB9hFQB9hFCvAAQCwAAB+BFQB8BFAABhQAABih8BFQh+BFiwAAQiwAAh8hFg");
	this.shape_15.setTransform(71.7,75);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E0E0E0").s().p("AksCnQh9hFAAhiQAAhhB9hFQB9hFCvAAQCwAAB+BFQB8BFAABhQAABih8BFQh+BFiwAAQiwAAh8hFg");
	this.shape_16.setTransform(71.7,72.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#E0E0E0").s().p("AksCnQh9hFAAhiQAAhhB9hFQB9hFCvAAQCwAAB+BFQB8BFAABhQAABih8BFQh+BFiwAAQivAAh9hFg");
	this.shape_17.setTransform(71.7,77.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E0E0E0").s().p("AhDiHQA4AAAnAoQAoAoAAA3QAAA4goAoQgnAog4AAg");
	this.shape_18.setTransform(136.7,98.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E0E0E0").s().p("AgbBgQgogoAAg4QAAg3AogoQAngoA4AAIAAEPQg4AAgngog");
	this.shape_19.setTransform(6.8,98.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F2F2F2").s().p("AmaNvQiriqAAjxIAAunQAAjxCriqQCqirDwAAQDxAACqCrQCrCqAADxIAAOnQAADxirCqQiqCrjxAAQjwAAiqirg");
	this.shape_20.setTransform(71.8,127.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.body, new cjs.Rectangle(0,0,143.5,232.7), null);


(lib.robot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.star1();
	this.instance.parent = this;
	this.instance.setTransform(-3.2,-123.1,1,1,0,0,0,6.2,6.2);

	this.instance_1 = new lib.star2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(13.7,-108.5,1,1,0,0,0,8.4,8.4);

	this.instance_2 = new lib.eye();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0.8,-35.5,1,1,0,0,0,14,14);

	this.instance_3 = new lib.body();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0.2,13.1,1,1,0,0,0,71.8,116.3);

	this.instance_4 = new lib.righthand();
	this.instance_4.parent = this;
	this.instance_4.setTransform(59,-1.6,1,1,0,0,0,0.7,75.5);

	this.instance_5 = new lib.lefthand();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-57.9,-1.3,1,1,0,0,0,115.5,75.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.robot, new cjs.Rectangle(-173.4,-129.3,346.9,258.8), null);


// stage content:
(lib.animate = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// star-1
	this.instance = new lib.robot();
	this.instance.parent = this;
	this.instance.setTransform(225,190.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:190},0).wait(1).to({y:189.3},0).wait(1).to({y:188.6},0).wait(1).to({y:187.9},0).wait(1).to({y:187.2},0).wait(1).to({y:186.6},0).wait(1).to({y:185.9},0).wait(1).to({y:185.2},0).wait(1).to({y:184.5},0).wait(1).to({y:183.8},0).wait(1).to({y:183.1},0).wait(1).to({y:183.7},0).wait(1).to({y:184.4},0).wait(1).to({y:185},0).wait(1).to({y:185.6},0).wait(1).to({y:186.3},0).wait(1).to({y:186.9},0).wait(1).to({y:187.5},0).wait(1).to({y:188.2},0).wait(1).to({y:188.8},0).wait(1).to({y:189.4},0).wait(1).to({y:190.1},0).wait(1).to({y:190.7},0).wait(1));

	// shadow
	this.instance_1 = new lib.Symbol1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(225,339.4,1,1,0,0,0,33.5,5.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({scaleX:0.99,scaleY:0.99},0).wait(1).to({scaleX:0.98,scaleY:0.98,x:224.9},0).wait(1).to({scaleX:0.98,scaleY:0.98},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:225},0).wait(1).to({scaleX:0.96,scaleY:0.96},0).wait(1).to({scaleX:0.95,scaleY:0.95,x:224.9},0).wait(1).to({scaleX:0.95,scaleY:0.95},0).wait(1).to({scaleX:0.94,scaleY:0.94,x:225},0).wait(1).to({scaleX:0.93,scaleY:0.93},0).wait(1).to({scaleX:0.92,scaleY:0.92,x:224.9},0).wait(1).to({scaleX:0.91,scaleY:0.91,x:225},0).wait(1).to({scaleX:0.92,scaleY:0.92},0).wait(1).to({scaleX:0.93,scaleY:0.93},0).wait(1).to({scaleX:0.94,scaleY:0.94},0).wait(1).to({scaleX:0.94,scaleY:0.94,x:224.9},0).wait(1).to({scaleX:0.95,scaleY:0.95},0).wait(1).to({scaleX:0.96,scaleY:0.96,x:225},0).wait(1).to({scaleX:0.96,scaleY:0.96},0).wait(1).to({scaleX:0.97,scaleY:0.97},0).wait(1).to({scaleX:0.98,scaleY:0.98},0).wait(1).to({scaleX:0.99,scaleY:0.99,x:224.9},0).wait(1).to({scaleX:0.99,scaleY:0.99},0).wait(1).to({scaleX:1,scaleY:1,x:225},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(276.6,236.4,346.8,283.7);
// library properties:
lib.properties = {
	id: '28ABF641DFD64919A93020F400CE455F',
	width: 450,
	height: 350,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['28ABF641DFD64919A93020F400CE455F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createHolylightBodyjs = createjs||{}, AdobeAn = AdobeAn||{});
var createHolylightBodyjs, AdobeAn;